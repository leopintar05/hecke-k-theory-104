"""Prime-by-prime determinants of one degree-104 packed matrix with exact CRT."""
import argparse
import hashlib
import json
from math import gcd, prod
from pathlib import Path
from time import monotonic

from flint import ctx, fmpz, fmpz_mod_ctx, fmpz_mod_mat, nmod_mat


def determinant(source, n, modulus, prime):
    width = (modulus.bit_length() + 7) // 8
    matrix = (nmod_mat(n, n, prime) if prime.bit_length() < 64
              else fmpz_mod_mat(n, n, fmpz_mod_ctx(prime)))
    digest = hashlib.sha256()
    with source.open("rb") as stream:
        for i in range(n):
            row = stream.read(n * width)
            assert len(row) == n * width
            digest.update(row)
            for j in range(n):
                x = int.from_bytes(row[width * j:width * (j + 1)], "little")
                assert x < modulus
                matrix[i, j] = x % prime
        assert not stream.read(1)
    print("Loaded", prime.bit_length(), "bit matrix", flush=True)
    return int(matrix.det()), digest.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("config", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--threads", type=int, default=3)
    args = p.parse_args()
    if not __debug__:
        p.error("Run with assertions enabled.")
    cfg = json.loads(args.config.read_text())
    n, modulus = cfg["rank"], cfg["modulus"]
    assert n == 2925 and cfg["e"] == 52
    primes = [43279339111, 490440141803, 63421406191963401438831238997,
              9627145162444529259385469643803339283582057016858454177128623918856377610117459003906333697523672786295588386036612994769077939963]
    assert len(set(primes)) == 4 and all(fmpz(p).is_prime() for p in primes)
    assert prod(primes) == modulus
    assert args.source.stat().st_size == n*n*((modulus.bit_length()+7)//8)
    ctx.threads = args.threads
    start = monotonic()
    results = []
    combined = 0
    used = 1
    digest = None
    for prime in primes:
        d, current = determinant(args.source, n, modulus, prime)
        if digest is None:
            digest = current
        assert digest == current
        combined += used * ((d-combined) * pow(used,-1,prime) % prime)
        used *= prime
        results.append({"prime": str(prime), "determinant": str(d)})
        print("Prime", prime, "determinant", d, "elapsed", round(monotonic()-start,1), flush=True)
    assert used == modulus and 0 <= combined < modulus
    assert all(combined % int(r["prime"]) == int(r["determinant"]) for r in results)
    result = {"rank": n, "modulus": str(modulus), "packed_sha256": digest,
              "components": results, "determinant_mod_M": str(combined),
              "gcd": str(gcd(combined, modulus))}
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print("CRT determinant", combined, "gcd", result["gcd"], "SHA-256", digest, flush=True)


if __name__ == "__main__":
    main()
