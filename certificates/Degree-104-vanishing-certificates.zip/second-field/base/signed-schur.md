# The signed auxiliary-field test on the standard lattice class

Let $E=\mathbb Q(\sqrt{-7})$, $w=(1+\sqrt{-7})/2$, and $m=e-1$. At the split prime 2 let $T$ be the directed neighbor operator scaled by $2^m$. Its conjugate $T^c$ is the oppositely directed operator with the same scaling. Write $H_0\oplus H_1$ for the standard and nonstandard lattice classes and use the two-class decomposition established in the earlier proof. Thus

\[
 T=\begin{pmatrix}A&B\\D&0\end{pmatrix},\qquad
 T^c=\begin{pmatrix}A'&B'\\D'&0\end{pmatrix},
 \qquad u=2^{2e}+2^e+1.
\]

The class involution induced by conjugation of $E$ preserves each class since the standard class is stable and there are exactly two classes. With the coefficient involution on the standard class given by $S f(x,y)=f(y,x)$, this gives a linear involution on the full complex space exchanging $T$ with $T^c$. An identification of the nonstandard class with its conjugate is unique up to its lattice stabilizer, which acts trivially on its invariant coefficient space.

Let a genuine cuspidal non-self-dual packet $\Pi$ and its distinct conjugate $\Pi^c$ occur with the full level and fixed weight. The associated simultaneous eigenvectors $v,Sv$ are independent, and have the same eigenvalue $\lambda+\lambda'$ for $T+T^c$ because their two directed eigenvalues are interchanged. Hence the eigenvalue occurs on both signed spaces, via $v+Sv$ and $v-Sv$. A fixed global residual witness makes $\lambda\equiv\lambda'\equiv u$ at the same coefficient place. For odd $p$ the signed projectors $(I\pm S)/2$ are integral; the eigenvalue congruence forces the characteristic polynomial of the sum on each signed full space to vanish at $2u$ modulo $p$. If $u$ is a unit, the lower-right block can be eliminated separately on each sign. Equivalently an eigenvector at $2u$ has nonzero first component. Thus each signed endomorphism of $H_0$ has zero determinant modulo $p$, where the endomorphism is

\[
 K=(2u)^2I-2u(A+A')-(B+B')(D+D').
\]

Either nonzero signed determinant suffices to exclude this branch. The directed certified Schur test in the earlier proof applies independently to all compact branches.

## Enumeration of the mixed paths

The first term $A$ uses the six known standard-to-standard neighbors. The seven paths $BD$ go through the nonstandard class in the same direction. Conjugation supplies $A'$ and $B'D'$. For the seven paths $BD'$ choose the even root of $w$ above 2 and start with the unique missing index-two hyperplane at that place,
\[
 P=\{(x_1,x_2,x_3)\in\mathbb Z_2^3:x_1+x_2+x_3\equiv0\pmod2\}.
\]
An opposite step is a superlattice $Y$ with $P\subset Y\subset\tfrac12P$ and $[Y:P]=2$. There are seven by the seven lines in $P/2P$. Its conjugate local component is fixed by unitarity. At the other finite primes the lattice stays standard. A rational unitary frame for a standard endpoint has the form $g=M/2$ with integral columns, $M^*M=4I$. It has $\det M=\pm8$: the determinant has valuation three at each of the two primes over 2 by $[\mathbb Z_2^3:P]=[Y:P]=2$, and $E$ has only the scalar units $\pm1$. Each frame constructed in this way provides an actual endpoint when $2P\subset M\mathbb Z_2^3\subset P$ at the chosen root. In `mixed-paths.py` the columns are enumerated from all norm-four vectors up to sign, testing pairwise orthogonality and placing them in fixed order. The upper containment is the parity condition on each column. The lower containment is tested modulo four on the four even vectors of coordinate sum zero modulo four. In the accepted outputs the generated module modulo four has eight elements. Its full inverse image has index eight, equal to the actual index by $\det M=\pm8$, which proves the integral containment. The seven distinct modules obtained therefore exhaust the seven possible paths. Conjugating gives $B'D$.

The incidence substitutions for $M/2$ contribute the same scaled polynomial action $(M^*x,M^t y)$ as the two same-direction steps. Consequently the coefficientwise field trace of the single directed sum with weights $2u^2,-2u,-1,-1$ on the identity, first steps, same-direction return paths, and mixed return paths gives $K$. On $a+bw$ the trace is $2a+b$.

## Signed basis and numerical checks

Denote the earlier orbit basis by $P_j$ and let $d$ be the sorted exponent-difference label of $P_j$. If $d$ differs from its dual (negated reversal), take $P_j+\epsilon S P_j$ for every $j$ whose $d$ is the lexicographically earlier label of the pair. If $d$ equals its dual and is nonzero, the action of $S$ is triangular on the ordered powers in that block, with diagonal entries $(-1)^a$ for the exponent $a$ in the first $z$ coordinate. Select the columns with diagonal entry $\epsilon$. In the symmetric block $S=I$. The selected columns form a basis of the $\epsilon$-space at every odd coefficient prime: for paired blocks projection back to the first block recovers the original basis, and for each triangular self-dual block the selected pivots are $2$ and the rank is the multiplicity of $\epsilon$. This also follows from the explicit swap-column formula in `inert_schur.py`.

The scalar $e=1$ check gives zero in the positive space, in agreement with the scalar adjacency eigenvalue seven in each direction. In the $e=6$ control the original Python quadratic-ring evaluator constructs all forty transformed endpoint terms separately. Its full determinant quotient equals the product of the two native signed determinant quotients, computed at unrelated sample points. For the new $e=32$ tests use the four `sign-minus-*.log` files. The native rational evaluation uses `native_inert.py --sign -1` with `mixed-paths.py` beside it. It takes the same `--companions`, `--p`, `--e`, `--seed` and `--library` arguments as in `native-certificate.md`. For the 107-bit prime use the two-word kernel. The `--unit-only` switch also works on a signed space and proves invertibility from the numerator determinant alone.
