"""Resume packed rows from a whole-row boundary and append newly computed chunks in order."""
import argparse
import os
from concurrent.futures import ProcessPoolExecutor
from math import comb
from pathlib import Path
from time import monotonic
from generate_folded import generate

def assemble(e,N,seed,base,lib,dest,workers,chunk):
    n=comb(e//2+1,3); row_size=n*((N.bit_length()+7)//8)
    dest.parent.mkdir(exist_ok=True,parents=True)
    completed=dest.stat().st_size//row_size if dest.exists() else 0
    assert completed<=n
    start=monotonic()
    with dest.open('ab') as out, ProcessPoolExecutor(max_workers=workers) as pool:
        out.truncate(completed*row_size)
        jobs=[]
        for a in range(completed,n,chunk):
            b=min(a+chunk,n)
            file=dest.with_suffix(f'.{a}-{b}.part')
            job=pool.submit(generate,e,N,seed,base,lib,file,a,b)
            jobs.append((a,b,file,job))
        for a,b,file,job in jobs:
            job.result()
            block=file.read_bytes()
            assert len(block)==(b-a)*row_size and out.tell()==a*row_size
            out.write(block);out.flush()
            file.unlink()
            print('rows',b,'/',n,'seconds',round(monotonic()-start,1),flush=True)
    assert dest.stat().st_size==n*row_size

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('e',type=int);p.add_argument('modulus',type=int);p.add_argument('seed',type=int)
    p.add_argument('companions',type=Path);p.add_argument('library',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--workers',type=int,default=1);p.add_argument('--chunk',type=int,default=32)
    a=p.parse_args()
    assemble(a.e,a.modulus,a.seed,a.companions,a.library,a.output,a.workers,a.chunk)
