"""Re-evaluate both orientations of every path directly on the signed polynomials."""
import hashlib
from pathlib import Path
from random import Random
from runpy import run_path

def direct_row(cfg,index,base):
    raw=run_path(str(base/'compact-minus-seven.py'))
    mixed=run_path(str(base/'mixed-paths.py'))['mixed'](base)
    e,p,seed=cfg['e'],cfg['modulus'],cfg['seed']
    raw['QuadraticResidue'].__init__.__globals__['p']=p
    labels=[]
    for t in raw['basis'](e-1,2):
        d,kind,a,b=t
        dual=tuple(-h for h in reversed(d))
        if d<dual or (d==dual and kind=='ordered' and a%2): labels.append(t)
    rng=Random(seed)
    for _ in range(index+1):a,b,c,d=[rng.randrange(1000,100000) for j in range(4)]
    x,y=(1,a,b),(-a*c-b*d,c,d)
    u=2**(2*e)+2**e+1
    def signed_values(x,y):
        return [a-b for a,b in zip(raw['values'](labels,x,y,2),raw['values'](labels,y,x,2))]
    sums=[raw['QuadraticResidue'](4*u*u*v) for v in signed_values(x,y)]
    for coeff,matrices in ((-2*u,raw['neighbors']['endpoint_matrices'](1)),(-1,raw['neighbors']['endpoint_matrices'](2)),(-1,mixed)):
        for M in matrices:
            conjugate=tuple(tuple(raw['neighbors']['bar'](z) for z in col) for col in M)
            for frame in (M,conjugate):
                xx,yy=raw['numerator_action'](frame,x,y)
                sums=[v+coeff*term for v,term in zip(sums,signed_values(xx,yy))]
    assert all(v.b==0 for v in sums)
    width=(p.bit_length()+7)//8
    return b''.join(v.a.to_bytes(width,'little') for v in sums)

def compare(cfg,index,base,path):
    data=direct_row(cfg,index,base)
    with path.open('rb') as src:
        src.seek(index*len(data))
        assert src.read(len(data))==data
    print('40-path exact comparison',cfg['e'],'row',index,'rank',cfg['rank'],'SHA-256',hashlib.sha256(data).hexdigest(),flush=True)
