"""Rebuild selected degree-104 rows from all 40 directions, without the speedups.

Pass the through-100 certificate ZIP and the degree-104 configuration. With
--packed, compare to the supplied row-major little-endian matrix in addition.
"""

import argparse
import hashlib
import json
from math import comb, gcd, prod
from pathlib import Path
from runpy import run_path
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def main(archive, config, packed):
    cfg = json.loads(config.read_text())
    assert cfg["e"] == 52 and cfg["rank"] == comb(27, 3)
    p1, p2, p3 = 43279339111, 490440141803, 63421406191963401438831238997
    b53, b105 = cfg["b"]
    p4, leftover = divmod(b105, 2162)
    assert leftover == 0 and b53 == 2*p1*p2*p3
    modulus = cfg["modulus"]
    assert prod((p1,p2,p3,p4)) == modulus and modulus.bit_length() == 602
    assert gcd(42*(2**104 + 2**52 + 1), modulus) == 1
    assert 104 * (2*52**3 + 6*(4*52+3)) < p1 - 1
    with ZipFile(archive) as old, TemporaryDirectory() as tmp:
        root = Path(tmp)
        names = ["direct_row.py"] + ["base/"+file for file in
                 ("compact-minus-seven.py","compact-series.py","minus-seven-neighbors.py","mixed-paths.py")]
        for name in names:
            old.extract(name, root)
        direct = run_path(str(root / "direct_row.py"))["direct_row"]
        for index in (1, 1462, 2924):
            row = direct(cfg, index, root / "base")
            assert len(row) == 2925 * 76
            if packed:
                with packed.open("rb") as stream:
                    stream.seek(index * len(row))
                    assert stream.read(len(row)) == row
            print(index, hashlib.sha256(row).hexdigest(), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("config", type=Path)
    parser.add_argument("--packed", type=Path)
    args = parser.parse_args()
    main(args.archive, args.config, args.packed)
