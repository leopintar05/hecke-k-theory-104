"""Check the stored degree-104 arithmetic chain. Requires only Python 3.10+."""

import argparse
import hashlib
import json
import sys
from math import comb, gcd, prod
from pathlib import Path
from zipfile import ZipFile


def log_values(text, prefix):
    [line] = [line for line in text.splitlines() if line.startswith(prefix)]
    return line[len(prefix):].strip().split()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--matrix", type=Path, help="also check SHA-256 of the reconstructed rows")
    args = parser.parse_args()
    if not __debug__:
        parser.error("Run with assertions enabled.")
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)
    here = Path(__file__).resolve().parent
    with ZipFile(here / "prior/Degree-104-rank-324-certificates.zip") as archive:
        first = json.loads(archive.read("support.json"))
        dx, dz = [int(archive.read(name)) for name in first["determinant_files"]]
    primes = [int(p) for p in first["large_candidate_primes"]]
    a, b, c, large = primes
    b53, b105 = (int(first[key]) for key in ("b53", "b105"))
    assert b53 == 2*a*b*c and b105 == 2*23*47*large
    assert gcd(dx, dz) == 3**1578 * 5**33 * 11**31 * 19**18 * 23**6 * 29 * 79 * (b53 // 2)
    modulus = prod(primes)
    with ZipFile(here / "prior/Degree-104-lightweight-checks.zip") as archive:
        first_classical = archive.read("first-field/first.log").decode()
        level_seven = archive.read("classical/check.log").decode()
    c2, c7 = (int(log_values(first_classical, name)[0]) for name in ("C2 ", "C7 "))
    assert 4*gcd(c2, c7) == 3**166 * 5**12 * 11**4 * 19**6 * b105**2
    assert list(map(int, log_values(level_seven, "d 3 divided Bernoulli numerators"))) == [b53, b105]
    second_pair = list(map(int, log_values(level_seven, "d 7 divided Bernoulli numerators")))
    assert gcd(prod(second_pair), b53*b105) == 4
    for label in ("adjoint weight 53 rank 101 residue ", "classical weight 105 rank 205 residue "):
        residue, _, _ = log_values(level_seven, label)
        assert gcd(int(residue), modulus) == 1
    assert gcd(42*(2**104 + 2**52 + 1), modulus) == 1
    result = json.loads((here / "degree104-result.json").read_text())
    assert result["rank"] == comb(27, 3) and int(result["modulus"]) == modulus
    config = json.loads((here / "second-field/config104.json").read_text())
    assert config["degree"] == 104 and config["e"] == 52 and config["rank"] == result["rank"]
    assert config["candidate_primes"] == primes and config["modulus"] == modulus
    assert result["packed_sha256"] == config["packed_sha256"]
    components = [(int(item["prime"]), int(item["determinant"])) for item in result["components"]]
    assert [p for p,_ in components] == primes
    assert all(0 <= r < p for p, r in components)
    crt = sum(r * (modulus//p) * pow(modulus//p, -1, p) for p, r in components) % modulus
    assert crt == int(result["determinant_mod_M"])
    assert gcd(crt, modulus) == int(result["gcd"]) == 1
    assert all(crt % p == r for p, r in components)
    if args.matrix:
        digest = hashlib.sha256()
        width = (modulus.bit_length() + 7) // 8
        assert args.matrix.stat().st_size == result["rank"]**2 * width
        with args.matrix.open("rb") as stream:
            for block in iter(lambda: stream.read(1024*1024), b""):
                digest.update(block)
        assert digest.hexdigest() == result["packed_sha256"]
    print("First-field support, classical exclusions and the reconstructed CRT residue agree.")
    print("Gcd of the second-field determinant with the four-prime product:", gcd(crt, modulus))


if __name__ == "__main__":
    main()
