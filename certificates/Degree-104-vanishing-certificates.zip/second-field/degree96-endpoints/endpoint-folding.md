# Exact reductions for the signed row generator at exponent 48

Put \(w=(1+\sqrt{-7})/2\), \(m=e-1\) and \(u=2^{2e}+2^e+1\). In the established order the single directed expression whose coefficientwise field trace gives the signed Schur operator has weights \(2u^2\) at the identity, \(-2u\) on the six first neighbors, and \(-1\) on the fourteen return paths. On a signed polynomial \(P-SP\), the two terms in each orbit summand have the same factors in \(z_j=x_jy_j\). Their prefactors are subtracted before multiplication by these factors.

Number the twenty integral path frames from zero, keeping the identity separate. Direct comparisons in the generator check
\[
 M_{11}=\bar w\overline{M_0},\qquad M_{12}=\bar w\overline{M_1},\qquad M_6=\bar w\overline{M_2},\qquad M_{13}=-2I.
\]
Conjugating preserves the coefficientwise trace at rational incidence pairs. A scalar multiple \(cM\) multiplies the polynomial action by \(N(c)^m\) because the bidegree is \((m,m)\). Each of the first three frames therefore has combined weight \(-2u-2^m\), and the identity weight becomes \(2u^2-4^m\).

The frames numbered 3, 4 and 5 are diagonal with entries \(-\bar w,-\bar w,-w\) in the three coordinate permutations. Let \(\delta=w/\bar w\). Each term with signed exponent differences \(2d_1,2d_2,2d_3\) acquires the sum of multipliers \(2^m\sum_i\delta^{-2d_i}\). Swapping the two triples conjugates this sum. Its trace therefore supplies the same rational multiplier for an entire signed column. From \(w+\bar w=1,\ w\bar w=2\), we obtain \(\delta^2+\delta^{-2}=1/4\). Define \(t_h=4^h(\delta^{2h}+\delta^{-2h})\). Then \(t_0=2,t_1=1,t_{h+1}=t_h-16t_{h-1}\). The identity coefficient before field trace, now depending on the orbit, becomes
\[
 2u^2-4^m-u\sum_{i=1}^3 2^{m-2|d_i|}t_{|d_i|}.
\]
All powers of 2 here have nonnegative exponents in the indicated orbit basis. The remaining ten return frames have coefficient \(-1\). This leaves fourteen evaluated transforms including identity. Where all three \(z_j\) are rational, the quadratic-ring trace contraction only needs its rational-coordinate product. The mixed Montgomery accumulation bound \(252N<2^{64L}\) from the full twenty-one-term computation also applies to these fourteen transforms because every algebraic weight is reduced before multiplication.

The separate forty-oriented-path Python check uses the original full collection of matrices and both polynomial evaluations \(P(x,y),P(y,x)\). A reproducer can use the original directed frame list and signed 21-transform implementation for every row.
