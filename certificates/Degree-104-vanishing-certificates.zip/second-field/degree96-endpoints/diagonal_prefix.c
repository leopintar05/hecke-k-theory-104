/* Multiword Montgomery arithmetic for the quadratic Schur evaluation. Build
   once for each desired word count L. Python supplies Montgomery-form inputs,
   R=2^(64L) mod p, and a prime p<2^(64L-1). All words are little endian. */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifndef L
#define L 2
#endif
typedef uint64_t U;
typedef __uint128_t W;
typedef struct { U v[L]; } Elem;
typedef struct { Elem a,b; } Pair;
static Elem p, one;
static U neg_inv;
static inline int ge(Elem a, Elem b) {
    for(int j=L-1;j>=0;j--) if(a.v[j]!=b.v[j]) return a.v[j]>b.v[j];
    return 1;
}
static inline Elem subtract_words(Elem a, Elem b) {
    U borrow=0;
    for(int j=0;j<L;j++) {
        U x=a.v[j],y=b.v[j];
        a.v[j]=x-y-borrow;
        borrow=(x<y) || (borrow && x==y);
    }
    return a;
}
static inline Elem add_words(Elem a,Elem b) {
    U carry=0;
    for(int j=0;j<L;j++) {
        W t=(W)a.v[j]+b.v[j]+carry;
        a.v[j]=(U)t; carry=(U)(t>>64);
    }
    return a;
}
static inline Elem add(Elem a,Elem b) {
    Elem c=add_words(a,b);
    return ge(c,p) ? subtract_words(c,p) : c;
}
static inline Elem sub(Elem a,Elem b) {
    if(!ge(a,b)) a=add_words(a,p);
    return subtract_words(a,b);
}
/* Textbook multiplication followed by word-wise Montgomery REDC. */
static inline Elem mul(Elem a, Elem b) {
    U t[2*L+1]={0};
    for(int i=0;i<L;i++) {
        U carry=0;
        for(int j=0;j<L;j++) {
            W v=(W)a.v[i]*b.v[j]+t[i+j]+carry;
            t[i+j]=(U)v; carry=(U)(v>>64);
        }
        t[i+L]=carry;
    }
    for(int i=0;i<L;i++) {
        U m=t[i]*neg_inv, carry=0;
        for(int j=0;j<L;j++) {
            W v=(W)m*p.v[j]+t[i+j]+carry;
            t[i+j]=(U)v; carry=(U)(v>>64);
        }
        for(int j=i+L;carry;j++) {
            W v=(W)t[j]+carry;
            t[j]=(U)v; carry=(U)(v>>64);
        }
    }
    Elem c;
    memcpy(c.v,t+L,sizeof(c.v));
    return ge(c,p) ? subtract_words(c,p) : c;
}
static inline Elem load(const U *a) { Elem x; memcpy(x.v,a,sizeof(x)); return x; }
static inline void store(U *a,Elem x) { memcpy(a,x.v,sizeof(x)); }
static inline int nz(Elem a) {
    U v=0; for(int j=0;j<L;j++) v|=a.v[j];
    return v!=0;
}
static inline Pair qadd(Pair a,Pair b) {
    return (Pair){add(a.a,b.a),add(a.b,b.b)};
}
static inline Pair qmul(Pair a,Pair b) {
    if (!nz(b.b)) {
        Elem ac=mul(a.a,b.a);
        return (Pair){ac,nz(a.b)?mul(a.b,b.a):(Elem){0}};
    }
    if (!nz(a.b)) return (Pair){mul(a.a,b.a),mul(a.a,b.b)};
    Elem ac=mul(a.a,b.a), bd=mul(a.b,b.b);
    return (Pair){sub(ac,add(bd,bd)),sub(mul(add(a.a,a.b),add(b.a,b.b)),ac)};
}
int num_words(void) { return L; }
void initialize(const U *prime,const U *mont_one) {
    p=load(prime); one=load(mont_one);
    U inv=1;
    for(int j=0;j<6;j++) inv*=2-p.v[0]*inv;
    neg_inv=0-inv;
}
/* Exposed for randomized arithmetic checks before evaluating a matrix. */
void field_product(const U *a,const U *b,U *out) {store(out,mul(load(a),load(b)));}
static int canonical_evaluate(int m,int n,int npre,const int *preargs,const int *offset,
             const int *terms,const U *points,const U *coeffs,int count,U *output) {
    Pair powers[14][m+1], pre[npre], sum[n];
    for(int j=0;j<n;j++) sum[j]=(Pair){0};
    for(int a=0;a<count;a++) {
        Pair v[14];
        for(int k=0;k<6;k++) v[k]=(Pair){
            load(points+L*(12*a+2*k)),
            load(points+L*(12*a+2*k+1))};
        for(int k=0;k<3;k++) v[6+k]=qmul(v[k],v[k+3]);
        Pair incidence=qadd(qadd(v[6],v[7]),v[8]);
        if(nz(incidence.a) || nz(incidence.b)) return 1;
        for(int k=0;k<3;k++) v[9+k]=qmul(v[6+(k+1)%3],v[6+(k+2)%3]);
        v[12]=qadd(qadd(v[9],v[10]),v[11]);
        v[13]=qmul(v[6],v[9]);
        for(int k=0;k<14;k++) {
            powers[k][0]=(Pair){one,{0}};
            for(int t=1;t<=m;t++) powers[k][t]=qmul(powers[k][t-1],v[k]);
        }
        for(int k=0;k<npre;k++) {
            Pair value={one,{0}};
            for(int j=0;j<3;j++) {
                int h=preargs[3*k+j];
                if(h) value=qmul(value,powers[h>0?j:3+j][abs(h)]);
            }
            pre[k]=value;
        }
        const Elem coefficient=load(coeffs+L*a);
        for(int j=0;j<n;j++) {
            Pair s={0};
            for(int q=offset[j];q<offset[j+1];q++) {
                const int *t=terms+5*q;
                Pair z=qmul(powers[t[1]][t[2]],powers[t[3]][t[4]]);
                s=qadd(s,qmul(pre[t[0]],z));
            }
            sum[j]=qadd(sum[j],(Pair){mul(s.a,coefficient),mul(s.b,coefficient)});
        }
    }
    for(int j=0;j<n;j++) {
        store(output+2*L*j,sum[j].a); store(output+L*(2*j+1),sum[j].b);
    }
    return 0;
}

/* Accumulate ordinary, unsigned full products. The caller checks that
 * 2*6*count*p < R, so even the largest accumulated dot product is < p*R.
 * Thus a single Montgomery reduction is valid for the full dot product.
 */
static inline void accumulate(U *t,Elem a,Elem b) {
    for (int i=0;i<L;i++) {
        U carry=0;
        for (int j=0;j<L;j++) {
            W v=(W)a.v[i]*b.v[j]+t[i+j]+carry;
            t[i+j]=(U)v; carry=(U)(v>>64);
        }
        for (int j=i+L;carry;j++) {
            W v=(W)t[j]+carry;
            t[j]=(U)v; carry=(U)(v>>64);
        }
    }
}
static inline Elem reduce(U *t) {
    for(int i=0;i<L;i++) {
        U m=t[i]*neg_inv, carry=0;
        for(int j=0;j<L;j++) {
            W v=(W)m*p.v[j]+t[i+j]+carry;
            t[i+j]=(U)v; carry=(U)(v>>64);
        }
        for(int j=i+L;carry;j++) {
            W v=(W)t[j]+carry;
            t[j]=(U)v; carry=(U)(v>>64);
        }
    }
    Elem c;
    memcpy(c.v,t+L,sizeof(c.v));
    return ge(c,p) ? subtract_words(c,p) : c;
}
int evaluate(int m,int n,int npre,const int *preargs,const int *offset,
             const int *terms,const U *points,const U *coeffs,int count,U *output) {
    if(count==1) return canonical_evaluate(m,n,npre,preargs,offset,terms,points,coeffs,count,output);
    /* Static indices depend only on this exponent's basis, fixed per process. */
    static int *idx,*order,nunique;
    int nt=offset[n], side=m+1;
    if (!idx) {
        int *map=malloc(sizeof(int)*14*14*side*side);
        if(!map) return 2;
        memset(map,255,sizeof(int)*14*14*side*side);
        idx=malloc(sizeof(int)*nt);
        order=malloc(sizeof(int)*nt);
        if(!idx||!order) return 2;
        for(int i=0;i<nt;i++) {
            const int *v=terms+5*i;
            int h=((v[1]*14+v[3])*side+v[2])*side+v[4];
            if(map[h]<0) {map[h]=nunique;order[nunique++]=i;}
            idx[i]=map[h];
        }
        free(map);
    }
    Pair powers[14][m+1], pre[npre], *mon=malloc(nunique*sizeof(Pair));
    U *sum=calloc((size_t)n*(2*L+1),sizeof(U));
    if(!mon||!sum) return 2;
    for(int a=0;a<count;a++) {
        Pair v[14];
        for(int k=0;k<6;k++) v[k]=(Pair){load(points+L*(12*a+2*k)),load(points+L*(12*a+2*k+1))};
        for(int k=0;k<3;k++) v[6+k]=qmul(v[k],v[k+3]);
        Pair incidence=qadd(qadd(v[6],v[7]),v[8]);
        if(nz(incidence.a)||nz(incidence.b)) return 1;
        for(int k=0;k<3;k++) v[9+k]=qmul(v[6+(k+1)%3],v[6+(k+2)%3]);
        v[12]=qadd(qadd(v[9],v[10]),v[11]);
        v[13]=qmul(v[6],v[9]);
        for(int k=0;k<14;k++) {
            powers[k][0]=(Pair){one,{0}};
            for(int t=1;t<=m;t++) powers[k][t]=qmul(powers[k][t-1],v[k]);
        }
        const Elem common_weight=load(coeffs+L*a);
        for(int k=0;k<npre;k++) {
            /* Identity and the three diagonal neighbors are simultaneously
               diagonal on each exponent-difference orbit after trace. */
            const Elem weight = a==0 ? load(coeffs+L*(count+k)) : common_weight;
            /* Only negative signed columns are encoded. The z-power factor is
               unchanged by swap, so the prefactors may be subtracted first. */
            Pair forward={weight,{0}}, backward={weight,{0}};
            for(int j=0;j<3;j++) {
                int h=preargs[3*k+j];
                if(h) {
                    forward=qmul(forward,powers[h>0?j:3+j][abs(h)]);
                    backward=qmul(backward,powers[h>0?3+j:j][abs(h)]);
                }
            }
            Pair value={sub(forward.a,backward.a),sub(forward.b,backward.b)};
            pre[k]=(Pair){add(add(value.a,value.a),value.b),sub(value.a,add(add(value.b,value.b),value.b))};
        }
        for(int k=0;k<nunique;k++) {
            const int *v=terms+5*order[k];
            mon[k]=qmul(powers[v[1]][v[2]],powers[v[3]][v[4]]);
        }
        if(!nz(v[6].b) && !nz(v[7].b) && !nz(v[8].b)) {
            for(int j=0;j<n;j++) {
                U *acc=sum+j*(2*L+1);
                for(int q=offset[j];q<offset[j+1];q++)
                    accumulate(acc,pre[terms[5*q]].a,mon[idx[q]].a);
            }
        } else {
        for(int j=0;j<n;j++) {
            U *acc=sum+j*(2*L+1);
            for(int q=offset[j];q<offset[j+1];q++) {
                Pair A=pre[terms[5*q]], B=mon[idx[q]];
                accumulate(acc,A.a,B.a);
                accumulate(acc,A.b,B.b);
            }
        }
        }
    }
    for(int j=0;j<n;j++) {
        store(output+2*L*j,(Elem){0});
        store(output+L*(2*j+1),reduce(sum+j*(2*L+1)));
    }
    free(mon);free(sum);
    return 0;
}
