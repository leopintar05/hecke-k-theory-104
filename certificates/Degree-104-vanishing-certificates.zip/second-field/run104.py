"""Reconstruct the packed degree-104 second-field matrix and validate its digest."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from math import comb, gcd, prod
from pathlib import Path
from runpy import run_path
from time import monotonic

from flint import fmpz
from assemble_folded import assemble
from direct_row import direct_row


def check_inputs(config, base):
    e = config["e"]
    modulus = config["modulus"]
    assert e == 52 and config["degree"] == 2 * e
    assert config["rank"] == comb(e // 2 + 1, 3) == 2925
    generalized = run_path(str(base / "quadratic-eisenstein.py"))["generalized"]
    numerators = [abs((generalized(j, 3) / j).numerator) for j in (e + 1, 2 * e + 1)]
    assert numerators == config["b"]
    p1, p2, p3, p4 = config["candidate_primes"]
    assert 2**31 <= p1 < p2 < p3 < p4
    assert all(fmpz(q).is_prime() for q in config["candidate_primes"])
    assert numerators == [2 * p1 * p2 * p3, 2 * 23 * 47 * p4]
    assert config["removed"] == {"2": 2, "23": 1, "47": 1}
    assert prod(config["candidate_primes"]) == modulus
    assert modulus.bit_length() == config["bits"] == 602
    assert gcd(42 * (2 ** (2 * e) + 2**e + 1), modulus) == 1
    print("Four-prime degree-104 modulus verified.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--control-only", action="store_true")
    parser.add_argument("--composite-replay", action="store_true",
                        help="also run signed panel elimination modulo the full product")
    args = parser.parse_args()
    if not __debug__ or args.workers < 1:
        parser.error("Use assertions and at least one worker.")
    here = Path(__file__).resolve().parent
    base = here / "base"
    output = here / "generated"
    output.mkdir(exist_ok=True)
    config = json.loads((here / "config104.json").read_text())
    check_inputs(config, base)
    modulus = config["modulus"]
    seed = config["seed"]
    limbs = ((252 * modulus).bit_length() + 63) // 64
    lib = output / "folded.so"
    flags = ["-dynamiclib"] if sys.platform == "darwin" else ["-shared", "-fPIC"]
    subprocess.run([os.environ.get("CC", "cc"), "-O3", "-std=c99", f"-DL={limbs}",
                    *flags, str(here / "degree96-endpoints/diagonal_prefix.c"),
                    "-o", str(lib)], check=True)

    # Each exponent uses its own process since the kernel caches its basis indices.
    control = output / "control.bin"
    subprocess.run([sys.executable, str(here / "generate_folded.py"), "6", str(modulus),
                    str(seed), str(base), str(lib), str(control), "0", "4"], check=True)
    small = dict(config, e=6, rank=4)
    assert control.read_bytes() == b"".join(direct_row(small, i, base) for i in range(4))
    print("All 16 control entries match direct evaluation on 40 paths.", flush=True)
    if args.control_only:
        return

    start = monotonic()
    packed = output / "rows104.bin"
    assemble(config["e"], modulus, seed, base, lib, packed, args.workers, 24)
    assert packed.stat().st_size == 650227500
    with packed.open("rb") as src:
        digest = hashlib.file_digest(src, "sha256").hexdigest()
    assert digest == config["packed_sha256"]
    print("Packed SHA-256:", digest, "seconds", round(monotonic() - start, 1), flush=True)
    if args.composite_replay:
        from panel_verify import verify
        determinant, checked_hash = verify(packed, config["rank"], modulus)
        assert checked_hash == digest and gcd(modulus, determinant) == 1
        print("CRT residues:", [determinant % q for q in config["candidate_primes"]])


if __name__ == "__main__":
    main()
