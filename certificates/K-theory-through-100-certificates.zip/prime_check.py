"""Independently compute a whole-matrix determinant over a known prime factor."""
import argparse,json
from pathlib import Path
from flint import fmpz,fmpz_mod_ctx,fmpz_mod_mat,nmod_mat

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('degree',type=int,choices=(88,92,100))
    parser.add_argument('--work',type=Path,default=Path('replay-work'))
    a=parser.parse_args()
    if not __debug__:parser.error('enable assertions')
    e=a.degree//2
    primes={44:50177369101,46:200359623171439,50:109534107737962267421}
    q=primes[e];h=Path(__file__).resolve().parent
    c=json.loads((h/'weights.json').read_text())[str(e)];cert=json.loads((h/'certificates.json').read_text())[str(e)]
    N,n=c['modulus'],c['rank']
    assert fmpz(q).is_prime() and N%q==0
    width=(N.bit_length()+7)//8
    path=a.work/f"rows-{a.degree}-{c['seed']}.bin"
    assert path.stat().st_size==n*n*width
    A=nmod_mat(n,n,q) if q.bit_length()<63 else fmpz_mod_mat(n,n,fmpz_mod_ctx(q))
    with path.open('rb') as f:
        for i in range(n):
            row=f.read(n*width)
            for j in range(n):
                A[i,j]=int.from_bytes(row[j*width:(j+1)*width],'little')%q
    z=int(A.det())
    assert z!=0 and z==cert['determinant_mod_M']%q
    print('direct full prime determinant agrees:',a.degree,q,z)
if __name__=='__main__':main()
