"""Exact determinant at inert 2 on full-lattice U(3) over the Eisenstein integers.

Usage: python3 compact-series.py 6 8 10 12 14 16
All computation uses the Python 3 standard library.  basis(m), values(B,x,y)
and sample_points(B) also serve the independent split-prime Hecke computation.
"""
from argparse import ArgumentParser
from itertools import permutations, product
from math import gcd
from random import Random
from time import monotonic

PERM = tuple(permutations(range(3)))


class Eis:
    """Integral pair a+b*w, with w squared plus w plus one equal to zero."""
    __slots__ = ("a", "b")

    def __init__(self, a, b=0):
        self.a, self.b = a, b

    def __add__(self, other):
        if isinstance(other, int):
            return Eis(self.a+other, self.b)
        return Eis(self.a+other.a, self.b+other.b)

    __radd__ = __add__

    def __neg__(self):
        return Eis(-self.a, -self.b)

    def __sub__(self, other):
        return self + (-other)

    def __rsub__(self, other):
        return -self + other

    def __mul__(self, other):
        if isinstance(other, int):
            return Eis(self.a*other, self.b*other)
        a, b, c, d = self.a, self.b, other.a, other.b
        return Eis(a*c-b*d, a*d+b*c-b*d)

    __rmul__ = __mul__

    def __pow__(self, n):
        if n < 0:
            raise ValueError("nonnegative exponents required")
        if not n:
            return Eis(1)
        if n == 1:
            return self
        half = self**(n//2)
        res = half*half
        return res*self if n % 2 else res

    def bar(self):
        return Eis(self.a-self.b, -self.b)

    def __eq__(self, other):
        if isinstance(other, int):
            return self.a == other and self.b == 0
        if isinstance(other, Eis):
            return self.a == other.a and self.b == other.b
        return NotImplemented

    def __repr__(self):
        return f"Eis({self.a},{self.b})"


def basis(m, unit_order=6):
    """Basis indices (d,label,i,j); m is the compact highest-weight parameter."""
    zero = (0,0,0)
    result = [(zero, "symmetric", a, (m-2*a)//3) for a in range(m//2+1)
              if (m-2*a) % 3 == 0]
    limit = m//unit_order
    for d0 in range(1, limit+1):
        for d1 in range(-limit, d0+1):
            d2 = -d0-d1
            d = (d0, d1, d2)
            k = m - unit_order*sum(max(t, 0) for t in d)
            if not -limit <= d2 <= d1 or k < 0:
                continue
            if len(set(d)) == 3:
                result += [(d, "ordered", a, k-a) for a in range(k+1)]
            else:
                result += [(d, "paired", k-2*b, b) for b in range(k//2+1)]
    return tuple(result)


def values(B, x, y, unit_order=6):
    """Evaluate the invariant basis on one incidence pair, over integers or Eis."""
    z = [a*b for a, b in zip(x, y)]
    assert sum(z) == 0
    s2, s3 = z[0]*z[1]+z[0]*z[2]+z[1]*z[2], z[0]*z[1]*z[2]
    powers = {}

    def pw(key, base, n):
        k = key, n
        if k not in powers:
            powers[k] = base**n
        return powers[k]

    def zp(i,n):
        return pw(("z",i),z[i],n)

    terms = {}
    row = []
    for d, label, a, b in B:
        if label == "symmetric":
            row.append(pw("s2", s2, a)*pw("s3", s3, b))
            continue
        if d not in terms:
            entries = []
            for perm in PERM:
                if label == "paired":
                    repeated = 0 if d[0] == d[1] else 1
                    if perm[repeated] > perm[repeated+1]:
                        continue
                prefactor = 1
                for i, exponent in zip(perm, d):
                    if exponent > 0:
                        prefactor *= pw(("x",i), x[i], unit_order*exponent)
                    elif exponent < 0:
                        prefactor *= pw(("y",i), y[i], -unit_order*exponent)
                entries.append((prefactor, perm))
            terms[d] = entries
        value = 0
        for prefactor, perm in terms[d]:
            if label == "ordered":
                i,j,_ = perm
                value += prefactor*zp(i,a)*zp(j,b)
            else:
                singleton = 2 if d[0] == d[1] else 0
                i = perm[singleton]
                j,k = (l for l in range(3) if l != i)
                value += prefactor*zp(i,a)*zp(j,b)*zp(k,b)
        row.append(value)
    return row


def complete_exactly(B, unit_order, points, evaluations):
    """Complete any independent sample by exhaustive search on a rational chart."""
    pivots = {}

    def independent(row):
        work = list(row)
        for i in range(len(work)):
            if work[i] == 0:
                continue
            if i not in pivots:
                pivots[i] = work
                return True
            pivot = pivots[i]
            coeff = work[i]
            work = [pivot[i]*a-coeff*b for a,b in zip(work,pivot)]
            common = gcd(*work)
            if common:
                work = [a//common for a in work]
        return False

    for row in evaluations:
        assert independent(row)
    radius = 0
    while len(points) < len(B):
        for a,b,c,d in product(range(radius+1),repeat=4):
            if max(a,b,c,d) != radius:
                continue
            x,y = (1,a,b), (-a*c-b*d,c,d)
            row = values(B,x,y,unit_order)
            if independent(row):
                points.append((x,y))
                evaluations.append(row)
                if len(points) == len(B):
                    return points,evaluations
        radius += 1
    return points,evaluations


def sample_points(B, unit_order=6, seed=78001):
    """Choose unisolvent rational pairs by an exact full-rank modular minor."""
    prime = 2**31-1
    rng = Random(seed)
    pivots, points, evaluations = {}, [], []
    tries = 0
    while len(points) < len(B):
        tries += 1
        if tries > max(1000,5*len(B)):
            return complete_exactly(B,unit_order,points,evaluations)
        radius = 3 + tries//100
        a,b,c,d = [rng.randint(-radius,radius) for _ in range(4)]
        x,y = (1,a,b), (-a*c-b*d,c,d)
        row = values(B,x,y,unit_order)
        reduced = [v % prime for v in row]
        for i in range(len(B)):
            if not reduced[i]:
                continue
            if i in pivots:
                coeff = reduced[i]
                reduced = [(v-coeff*w)%prime for v,w in zip(reduced,pivots[i])]
                continue
            inv = pow(reduced[i], -1, prime)
            pivots[i] = [v*inv%prime for v in reduced]
            points.append((x,y))
            evaluations.append(row)
            break
    return points, evaluations


def determinant(matrix):
    """Fraction-free Bareiss determinant, with row pivoting and exact divisions."""
    a = [r[:] for r in matrix]
    n, sign, prev = len(a), 1, 1
    if n == 0:
        return 1
    for k in range(n-1):
        if a[k][k] == 0:
            pivot_row = next((i for i in range(k+1,n) if a[i][k]), None)
            if pivot_row is None:
                return 0
            a[k], a[pivot_row] = a[pivot_row], a[k]
            sign *= -1
        pivot = a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                num = a[i][j]*pivot - a[i][k]*a[k][j]
                a[i][j], rem = divmod(num, prev)
                assert rem == 0
            a[i][k] = 0
        prev = pivot
    return sign*a[-1][-1]


def twice_image(x, b, i, j):
    result = [2*a for a in x]
    result[i] = x[i]+b*x[j]
    result[j] = x[j]-b.bar()*x[i]
    return result


def inert_two(B, points, evals, e):
    units = [Eis(1),Eis(0,1),Eis(-1,-1),Eis(-1),Eis(0,-1),Eis(1,1)]
    bs = [Eis(1,2)*u for u in units]
    scalar = 3*4**(e-1) - (4**(2*e)+4**e+1)
    result = []
    for (x,y),row in zip(points,evals):
        sums = [Eis(scalar*v) for v in row]
        for i,j in ((0,1),(0,2),(1,2)):
            for b in bs:
                v = values(B,twice_image(x,b,i,j),twice_image(y,b.bar(),i,j))
                sums = [a+t for a,t in zip(sums,v)]
        assert all(t.b == 0 for t in sums)
        result.append([t.a for t in sums])
    ratio, rem = divmod(determinant(result),determinant(evals))
    assert rem == 0
    return ratio


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("e", type=int, nargs="+", help="even twist e, compact m=e−1")
    args = parser.parse_args()
    for e in args.e:
        assert e >= 2 and e % 2 == 0
        start = monotonic()
        B = basis(e-1)
        points, evals = sample_points(B)
        res = inert_two(B, points, evals, e)
        if e == 6:
            assert res == -16777449
        if e == 8:
            assert res == -79228276291965330830049420825
        print(f"e={e} dim={len(B)} det2={res} seconds={monotonic()-start:.2f}",
              flush=True)


if __name__ == "__main__":
    main()
