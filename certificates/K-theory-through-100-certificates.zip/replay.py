"""Replay the compact Hecke certificate of a chosen degree on macOS or Linux."""
import argparse,json,os,subprocess,sys
from math import comb,gcd,prod
from pathlib import Path
from runpy import run_path
from flint import fmpz
from assemble import assemble
from direct_row import compare
from panel_verify import verify

def check_inputs(c,base):
    e=c['e']; b=run_path(str(base/'quadratic-eisenstein.py'))['generalized']
    nums=[abs((b(j,3)/j).numerator) for j in (e+1,2*e+1)]
    assert nums==c['b']
    removed={int(q):a for q,a in c['removed'].items()}
    assert all(1<q<2**31 and fmpz(q).is_prime() and a>0 for q,a in removed.items())
    n=c['modulus']
    assert prod(nums)==n*prod(q**a for q,a in removed.items())
    assert n.bit_length()==c['bits'] and gcd(n,42*(2**(2*e)+2**e+1))==1
    assert c['rank']==comb(e//2+1,3) and c['degree']==2*e
    print('candidate modulus verified for degree',2*e,flush=True)

def main():
    z=argparse.ArgumentParser(description=__doc__)
    z.add_argument('degrees',type=int,nargs='*',help='one or more degrees among 76,80,...,100')
    z.add_argument('--inputs-only',action='store_true')
    z.add_argument('--workers',type=int,default=1)
    z.add_argument('--work',type=Path,default=Path('replay-work'))
    args=z.parse_args()
    if not __debug__:z.error('run with Python assertions enabled')
    here=Path(__file__).resolve().parent; base=here/'base'
    weights=json.loads((here/'weights.json').read_text())
    expected=json.loads((here/'certificates.json').read_text()) if not args.inputs_only else {}
    degrees=args.degrees or (list(range(76,101,4)) if args.inputs_only else [])
    if not degrees:z.error('select a degree to replay, or use --inputs-only')
    if args.workers<1:z.error('--workers must be positive')
    for degree in degrees:
        if degree not in range(76,101,4):z.error('degree is outside this certificate')
        c=weights[str(degree//2)]
        check_inputs(c,base)
        if args.inputs_only:continue
        e,n,p,seed=c['e'],c['rank'],c['modulus'],c['seed']
        out=args.work.resolve(); out.mkdir(parents=True,exist_ok=True)
        L=((252*p).bit_length()+63)//64
        lib=out/f'signed-{L}.so'
        flags=['-dynamiclib'] if sys.platform=='darwin' else ['-fPIC','-shared']
        subprocess.run([os.environ.get('CC','cc'),'-O3','-std=c99',f'-DL={L}',*flags,str(here/'signed_prefix.c'),'-o',str(lib)],check=True)
        rows=out/f'rows-{degree}-{seed}.bin'
        assemble(e,p,seed,base,lib,rows,args.workers,32)
        compare(c,0,base,rows)
        residue,digest=verify(rows,n,p)
        assert residue==expected[str(e)]['determinant_mod_M']
        assert digest==expected[str(e)]['packed_sha256']
        print('complete certificate matches for degree',degree,flush=True)
if __name__=='__main__':main()
