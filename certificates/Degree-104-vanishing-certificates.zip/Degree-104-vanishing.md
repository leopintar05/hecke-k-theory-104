# Degree 104 closes under the same assumptions

**All four candidate primes fail the second-field test.** Let \(W\) be the rank-2,925 evaluation matrix for the calculation over \(\mathbb Q(\sqrt{-7})\), and let \(M\) be the product of the four candidate primes. The exact calculation gives

\[
\gcd(\det W,M)=1.
\]

Consequently, **under the specialized strict Selmer inequality and the transfer and common-witness arguments used through degree 100, applied also at \(e=52\),**

\[
K_{104}(\mathbb Z)=0,\qquad
K_{4k}(\mathbb Z)=0\quad(1\le k\le 26).
\]

The first field restricts all possible large primes to four. The second excludes those four. The determinant identity is an exact arithmetic result. The stated assumptions enter when passing from possible torsion in the \(K\)-group to a Hecke eigenvalue.

## What was computed

Let \(p_1=43\,279\,339\,111\), \(p_2=490\,440\,141\,803\), \(p_3=63\,421\,406\,191\,963\,401\,438\,831\,238\,997\). Write \(P=b_{3,105}/2162\) for the previously certified 130-digit prime, with \(b_{3,j}=|\operatorname{num}(B_{j,\eta_{-3}}/j)|\). Set \(M=p_1p_2p_3P\). It has 602 bits.

| Prime | Residue of \(\det W\) |
|---|---|
| \(p_1\) | \(32\,189\,186\,543\) |
| \(p_2\) | \(445\,745\,447\,561\) |
| \(p_3\) | \(22\,450\,212\,846\,525\,469\,764\,552\,672\,927\) |
| \(P\) | The nonzero integer below |

The residue modulo \(P\) is

    3852277615420153516322648794026152355051779200992105216587265891154157287653877960615145587434547466097567956069671093168965749031

We generated \(W\bmod M\) once. We reduced that same matrix modulo each of the four proved primes and computed each full determinant over the corresponding field. The Chinese remainder theorem combines the four values into the certified residue modulo \(M\). The companion archive contains the full decimal inputs and output in degree104-result.json.

## Why this finishes the degree

1. **Small primes.** The group \(K_{104}(\mathbb Z)\) has finite odd order. For an odd prime \(\ell\), its quotient modulo \(\ell\) is the \(\omega^{-52}\)-part of the cyclotomic class group modulo \(\ell\). This character is even, so the published verification of Vandiver for \(\ell<2^{31}\) excludes every smaller odd prime. [Weibel, Corollary VI.9.8](https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.VI.pdf#page=55) · [Jordan–Klagsbrun–Poonen–Skinner–Zaytman, Theorem 5.1](https://arxiv.org/html/1703.00108v3#S5) · [Hart–Harvey–Ong](https://arxiv.org/abs/1605.02398)
2. **Large primes outside the list.** Under the earlier Selmer and Hecke comparisons over \(\mathbb Q(\sqrt{-3})\), a prime dividing the group order must appear in at least one of the classical, self-dual, or non-self-dual cases. The Bernoulli and classical calculations and the two exact rank-324 determinants restrict their union above the cutoff to \(p_1,p_2,p_3,P\). The proof and both exact matrices are included in the companion archive.
3. **The four primes on the list.** Over \(\mathbb Q(\sqrt{-7})\), the earlier weight-53 and weight-105 classical calculations exclude the classical and genuinely self-dual cases for all four. In the remaining case a fixed residual witness must have the target eigenvalue in both directions at the split prime 2. The interpolation bound still holds at exponent 52, since \(104(2\cdot52^3+6(4\cdot52+3))=29\,378\,128<2^{31}-1\).
4. **The contradiction.** Put \(u=2^{104}+2^{52}+1\). A non-self-dual eigenvector and its distinct conjugate give a nonzero difference in the negative subspace. The eigenvalue of the sum of the directed operators on this vector reduces to \(2u\). Since \(\gcd(2u,M)=1\), the second lattice class can be eliminated by the Schur complement. The resulting operator \(L\) on the standard negative space would have determinant divisible by the candidate prime. The signed basis polynomials have integral evaluations, and \(W=V[L]\) in characteristic zero for their evaluation matrix \(V\). Hence that prime would also divide \(\det W\). Each of the four computed residues excludes this possibility.

Thus the argument only needs the first-field Selmer comparison at large primes outside the list and the second-field comparison at the four primes on it. The interpretation of Alpöge’s bound, the coverage of admitted representations by the calculated spaces, and the passage to a single residual witness retain the same review status as in the degree-100 argument.

## Checks and replay

The signed rank is \(\binom{27}{3}=2925\). A direct check evaluated all 40 oriented paths for each of the 2,925 entries in three separate rows, including the last row. All 8,775 entries agreed with the optimized generator. The same implementation also reproduced a complete rank-four control at the full 602-bit modulus. Every prime-field calculation read the same 650,227,500 bytes, with SHA-256

    1bc9fe6031fcebd83a58eef99b49a873a8085bf00a87d807d9532288110336d3

The archive includes the prior degree-104 certificates, the new matrix generator, the exact determinant verifier, and a short Python check of the arithmetic chain. It recreates the large matrix from source. On this machine the recorded row generation took 80 seconds and the four full determinant checks together took 104 seconds.
