"""Exact primitive odd quadratic generalized Bernoulli numbers for prime |d|=3,7."""
from fractions import Fraction
from functools import cache
from math import comb, gcd, lcm


@cache
def bernoulli(n):
    if n == 0:
        return Fraction(1)
    return -sum(comb(n+1, j)*bernoulli(j) for j in range(n))/(n+1)


def quadratic(d, n):
    assert d in (3, 7)
    return 0 if n % d == 0 else (1 if pow(n, (d-1)//2, d) == 1 else -1)


def generalized(k, d):
    result = Fraction(0)
    for a in range(1, d):
        x = Fraction(a, d)
        polynomial = sum(comb(k, j)*bernoulli(j)*x**(k-j) for j in range(k+1))
        result += quadratic(d, a)*polynomial
    return d**(k-1)*result


if __name__ == '__main__':
    p = 25078104767246023
    for e in range(6, 33, 2):
        k = 2*e+1
        b3, b7 = generalized(k,3), generalized(k,7)
        common = gcd(b3.numerator, b7.numerator)
        if e == 16:
            print('e=16 B33,eta(-7) =',b7)
            print('e=16 residues mod',p,':',*(x.numerator*pow(x.denominator,-1,p)%p for x in (b3,b7)))
        print('e =',e,'gcd of generalized B numerators =',common)
