"""Generate signed Schur evaluation rows in canonical little-endian residues.

Run in a fresh process per exponent. Each rank-sized row applies K to the
polynomials P-S(P), in the same fixed order as the proved orbit basis.
"""
import argparse
import ctypes as C
from math import comb,gcd
from pathlib import Path
from random import Random
from runpy import run_path

def minus_labels(all_labels):
    selected=[]
    for label in all_labels:
        d,kind,a,b=label
        dual=tuple(-h for h in reversed(d))
        if d<dual or (d==dual and kind=="ordered" and a%2):
            selected.append(label)
    return selected

def generate(e,N,seed,companions,library,outfile,begin,stop):
    basis=run_path(str(companions/'compact-series.py'))['basis'](e-1,2)
    selected=minus_labels(basis)
    n=len(selected)
    assert n==comb(e//2+1,3) and 0<=begin<=stop<=n
    u=2**(2*e)+2**e+1
    assert gcd(42*u,N)==1
    raw=run_path(str(companions/'minus-seven-neighbors.py'))
    M=raw['endpoint_matrices'](1)+raw['endpoint_matrices'](2)
    M+=run_path(str(companions/'mixed-paths.py'))['mixed'](companions)
    assert len(M)==20
    # Three same-direction returns are scalar multiples of conjugate first steps.
    # The backtrack is scalar. Norm, conjugation and bidegree give the integer
    # multipliers below on the rational field trace.
    for i,j in [(0,11),(1,12),(2,6)]:
        assert M[j]==tuple(tuple(raw["mul"]((1,-1),raw["bar"](v)) for v in col) for col in M[i])
    assert M[13]==tuple(tuple((-2*int(i==j),0) for i in range(3)) for j in range(3))
    m=e-1
    # The three diagonal first steps consist of a common scalar -bar(w)
    # and one exceptional coordinate scaled further by delta=w/bar(w).
    for i,A in enumerate(M[3:6]):
        assert A==tuple(tuple((0,0) if j!=k else ((0,-1) if j==2-i else (-1,1)) for k in range(3)) for j in range(3))
    coeff=[0]+[-2*u-2**m]*3+[-1]*10
    M=[M[i] for i in range(20) if i not in (3,4,5,6,11,12,13)]
    assert len(coeff)==len(M)+1
    cols=[col for matrix in M for col in matrix]
    enc=run_path(str(companions/'native_inert.py'))['encode_basis'](selected)
    lib=C.CDLL(str(library.resolve()))
    L=lib.num_words(); R=1<<(64*L)
    assert 252*N<R
    it=C.POINTER(C.c_int); word=C.c_uint64; ptr=C.POINTER(word)
    lib.initialize.argtypes=[ptr,ptr]
    lib.evaluate.argtypes=[C.c_int,C.c_int,C.c_int,it,it,it,ptr,ptr,C.c_int,ptr]
    wide=8*L
    output_width=(N.bit_length()+7)//8
    def words(values):
        data=b"".join(v.to_bytes(wide,'little') for v in values)
        return (word*(len(data)//8)).from_buffer_copy(data)
    def encode(values): return words([(v*R)%N for v in values])
    lib.initialize(words([N]),encode([1]))
    # t[h]=4^h(delta^(2h)+delta^(-2h)); delta^2+delta^(-2)=1/4.
    t=[2,1]
    for h in range(1,m//2): t.append(t[-1]-16*t[-2])
    identity=[]
    for i in range(enc[0]):
        exps=[abs(enc[1][3*i+j])//2 for j in range(3)]
        scalar=sum((1<<(m-2*h))*t[h] for h in exps)
        identity.append(2*u*u-4**m-u*scalar)
    weights=encode(coeff+identity)
    rinv=pow(R,-1,N)
    rng=Random(seed)
    out=(word*(2*n*L))()
    with outfile.open('wb') as file:
        for i in range(stop):
            a,b,c,d=(rng.randrange(1000,100000) for j in range(4))
            if i<begin: continue
            x,y=(1,a,b),(-a*c-b*d,c,d)
            coords=[v for z in x+y for v in (z,0)]
            for j in range(0,len(cols),3):
                block=cols[j:j+3]
                for vec,conjugate in ((x,True),(y,False)):
                    for col in block:
                        aa=sum(t*z[0] for t,z in zip(vec,col))
                        bb=sum(t*z[1] for t,z in zip(vec,col))
                        coords.extend((aa+bb,-bb) if conjugate else (aa,bb))
            assert lib.evaluate(e-1,n,*enc,encode(coords),weights,len(coeff),out)==0
            raw_row=bytes(out)
            entries=[]
            for k in range(wide,len(raw_row),2*wide):
                value=int.from_bytes(raw_row[k:k+wide],'little')*rinv%N
                entries.append(value.to_bytes(output_width,'little'))
            file.write(b''.join(entries))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('e',type=int);p.add_argument('modulus',type=int);p.add_argument('seed',type=int)
    p.add_argument('companions',type=Path);p.add_argument('library',type=Path);p.add_argument('outfile',type=Path)
    p.add_argument('begin',type=int);p.add_argument('end',type=int)
    a=p.parse_args()
    generate(a.e,a.modulus,a.seed,a.companions,a.library,a.outfile,a.begin,a.end)
