"""Enumerate seven paths through the other class with opposite step directions."""
from itertools import product
from pathlib import Path
from runpy import run_path
from argparse import ArgumentParser

def mixed(companions):
    raw=run_path(str(companions/'minus-seven-neighbors.py'))
    v=[x for x in raw['norm_lines'](4) if sum(a for a,b in x)%2==0]
    twoP=frozenset(x for x in product((0,2),repeat=3) if sum(x)%4==0)
    assert len(twoP)==4
    orth={i:{j for j in range(i+1,len(v)) if raw['dot'](v[i],v[j])==(0,0)}
          for i in range(len(v))}
    result={}
    for i in orth:
        for j in sorted(orth[i]):
            for k in sorted(orth[i]&orth[j]):
                M=(v[i],v[j],v[k])
                determinant=raw['determinant'](M)
                if determinant not in ((8,0),(-8,0)):continue
                H=raw['span'](M,4)
                assert len(H)==8
                if not twoP<=H:continue
                assert H not in result
                result[H]=M
    assert len(result)==7
    return list(result.values())

if __name__=='__main__':
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--companions',type=Path,required=True)
    args=parser.parse_args()
    for M in mixed(args.companions): print(M)
