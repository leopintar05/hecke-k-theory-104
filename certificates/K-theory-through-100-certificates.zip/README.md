# Conditional vanishing of the even K-groups in degrees divisible by four through 100

Start with **K-theory-through-100.pdf**. The unconditional part of the new computation is the exclusion of the doubled split-2 target eigenvalue on the negative signed space at every indicated coefficient prime. For each weight, the change from source-admitted representations to this one local exclusion uses the sharp Selmer estimate in the proof. The previous eighteen degrees, the first-field support calculation through 100, and the proof of fixed-witness detection are in **K-theory-through-72-certificates.zip**, including its earlier proof bundles.

## Reproduce a compact calculation

Use Python 3.10 or newer, a 64-bit C99 compiler supporting unsigned 128-bit integers, and python-flint 0.9.0. The recorded runs used Python 3.12 on Apple Silicon, Clang, and FLINT 3.6.0. Linux and macOS compilation flags are supplied by the driver. Run with assertions enabled.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install python-flint==0.9.0
python replay.py --inputs-only
python control.py
python replay.py 76
python replay.py 80 84 88 92 96 100
```

Each positional argument is a K-group degree. The driver recomputes the generalized Bernoulli numbers, verifies every removed prime, compiles the signed kernel, generates the matrix, verifies a row directly on all forty nonidentity paths, proves that the full matrix is invertible over the composite ring, and compares the final modular determinant and SHA-256 digest with **certificates.json**. For a direct determinant over one prime factor, run `python prime_check.py 100` after its main replay. Degrees 88 and 92 are also supported. The quick four-dimensional control independently evaluates every entry and uses an ordinary integer determinant as a second check.

To use three row workers, run `python replay.py 100 --workers 3`. The **replay-work** directory keeps row files. A resumed run starts at the first incomplete row and the digest is verified at the end. Use `--work PATH` to select a fresh location. A degree-100 row contains 2,600 canonical residues of 66 little-endian bytes each. The full packed matrix is 446,160,000 bytes. The archive contains source and logs from which the matrices can be regenerated.

## Read the certificate

- **weights.json** gives the seven Bernoulli pairs, removed prime powers, exact composite moduli, sample seed, and ranks. **certificates.json** gives the corresponding determinant residues and digests.
- **logs/panel-*.log** records each checked pivot determinant, then the full determinant and matrix hash. The ranks in these filenames are indexed by the exponent e, with K-group degree 2e. Every pivot has a verified right inverse. The product of its determinants gives the final residue by the Schur determinant identity.
- **logs/whole-inverse-*.log** records additional direct checks of a full right inverse over the composite modulus at e = 38, 40, 42. The row evaluations in those three runs used a separate signed-trace implementation. Its source and a replay driver are in **whole-inverse/**.
- **logs/independent-rows.log** records direct forty-path checks across the seven exponents. **direct_row.py** uses the original quadratic-ring polynomial arithmetic and explicitly swaps the two evaluated arguments.
- **base/signed-schur.md** proves the signed obstruction, explains both lattice classes, and derives and enumerates the seven mixed return paths. **signed-rank.md** gives the independent rotation-character dimension formula. **base/source-and-count.md** states the input for the fixed global residual witness.
- **generate.py** and **signed_prefix.c** evaluate each signed orbit polynomial by subtracting the swapped monomial prefix before summing. In the invariant variables each product of powers of the coordinates x_i y_i stays fixed under swap. The coefficient trace takes the form Tr((a+bw)(c+dw)) = (2a+b)c + (a−3b)d. For the fused Montgomery products the driver checks 252 M < R. Each weighted sum contains at most 21 × 6 × 2 base products, so one final reduction is exact.
- **degree96-endpoints/** documents the optional endpoint simplification used in part of the degree-96 production run. The main replay uses the full list for every row.
- **panel_verify.py** row-reduces square blocks over the actual composite ring. The equality P Q = I is checked explicitly for every pivot. The initial packed matrix follows the fixed orbit basis order and uses seed 128711. The digest identifies its serialized entries. The unit gcd and pivot inverse checks are the invertibility evidence.

## Prior arithmetic

The extracted **base/support-witnesses.json** contains the exact first-field gcds and discrepancy ratios. Run the command below for the standard quick check.

```sh
python base/support-check.py --weights 38 40 42 44 46 48 50
```

The included degree-72 bundle also gives the full first-field option `support-check.py --recompute`, the level-seven rational Hecke calculations at all 25 weights, and the earlier finite vanishing proofs. Rebuilding these earlier matrices requires the dependencies in that bundle. Its earlier checkpoints describe its state at the time of writing.

The mathematical result uses Alpöge's specialized sharp strict Selmer estimates. It yields the vanishing of 25 indicated real cyclotomic eigenspaces modulo each odd coefficient prime and corresponding primary vanishing in periodic higher degrees. The validity of the sharp estimates themselves remains open in this investigation.
