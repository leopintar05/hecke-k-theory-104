"""Exact common-prime constraints from conductor-3 forms in any odd weight >=5.

Only the Python 3 standard library is used. Run --help for the arguments.
"""
import argparse
import json
from math import gcd, isqrt, prod
from pathlib import Path
from functools import reduce


def eta_character(n):
    return (0, 1, -1)[n % 3]


def divisor_sums(limit):
    sigma = [0] * (limit + 1)
    theta = [0] * (limit + 1)
    theta[0] = 1
    for d in range(1, limit + 1):
        for n in range(d, limit + 1, d):
            sigma[n] += d
            theta[n] += 6 * eta_character(d)
    return sigma, theta


def basis(weight, order):
    # C A^(weight-6-3j) B^j. A is the hexagonal theta function.
    # B and C are the two eta quotients in gl2-audit.md.
    dim = (weight - 6) // 3 + 1
    sigma, theta = divisor_sums(order)
    # A' means q*d/dq here. Solve A*(A'/A)=A' coefficient by coefficient.
    log_theta = [0]
    for n in range(1, order + 1):
        log_theta.append(n * theta[n] - sum(theta[i] * log_theta[n-i] for i in range(1, n)))
    forms = []
    for j in range(dim):
        shift = 1 + j
        # q^-shift C A^r B^j has constant coefficient one. Its logarithmic
        # derivative has integral coefficients via the eta Euler product.
        r = weight - 6 - 3*j
        log_form = [0] + [r*log_theta[n] - (6-3*j)*sigma[n]
                          - (3*(6+9*j)*sigma[n//3] if n % 3 == 0 else 0)
                          for n in range(1, order - shift + 1)]
        raw = [1]
        for n in range(1, order - shift + 1):
            coeff, rem = divmod(sum(log_form[i] * raw[n-i] for i in range(1, n+1)), n)
            assert rem == 0
            raw.append(coeff)
        forms.append([0]*shift + raw)
    return forms


def hecke(forms, p, weight):
    columns = []
    for f in forms:
        coeffs = []
        for n in range(1, len(forms)+1):
            value = f[p*n] + (eta_character(p) * p**(weight-1) * f[n//p] if n % p == 0 else 0)
            assert forms[n-1][n] == 1
            coeffs.append(value - sum(c * forms[j][n] for j, c in enumerate(coeffs)))
        columns.append(coeffs)
    return list(zip(*columns))


def det_shift(matrix, shift):
    """Exact integer Bareiss elimination with row pivoting."""
    n = len(matrix)
    if n == 0:
        return 1
    a = [[x - (shift if i == j else 0) for j, x in enumerate(row)]
         for i, row in enumerate(matrix)]
    sign = 1
    divisor = 1
    for k in range(n-1):
        if not a[k][k]:
            pivot = next((i for i in range(k+1, n) if a[i][k]), None)
            if pivot is None:
                return 0
            a[k], a[pivot] = a[pivot], a[k]
            sign = -sign
        for i in range(k+1, n):
            for j in range(k+1, n):
                a[i][j], rem = divmod(a[k][k]*a[i][j] - a[i][k]*a[k][j], divisor)
                assert rem == 0
        divisor = a[k][k]
    return sign * a[-1][-1]


def residual_constraints(e, probes):
    k = 2*e + 1
    forms = basis(k, max(probes) * ((k-6)//3 + 1))
    values = []
    for p in probes:
        assert p != 3 and p >= 2 and all(p % d for d in range(2, isqrt(p)+1))
        h = hecke(forms, p, k)
        target = p**(k-1) + eta_character(p)
        value = det_shift(h, target)
        if eta_character(p) == -1:
            value *= det_shift(h, -target)
        assert value != 0
        values.append(abs(value))
    return values


def verify_factorizations():
    data = json.loads(Path(__file__).with_name('classical-factors.json').read_text())
    known = {2}
    for p, certificate in sorted(((int(p), c) for p, c in data['primality'].items())):
        a, fac = certificate
        assert all(int(q) in known for q in fac)
        assert prod(int(q)**v for q, v in fac.items()) == p-1
        assert pow(a, p-1, p) == 1
        assert all(pow(a, (p-1)//int(q), p) != 1 for q in fac)
        known.add(p)  # the unit a has order p-1, so phi(p) >= p-1
    for e, certificates in data['weights'].items():
        values = residual_constraints(int(e), (2, 7, 13))
        for kind, factors in certificates.items():
            value = reduce(gcd, values) if kind == "gcd" else values[0]
            assert all(int(q) in known for q in factors)
            assert prod(int(q)**v for q, v in factors.items()) == value
        print("verified e =", e, "gcd primes:", *certificates["gcd"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', type=int, default=6)
    parser.add_argument('--end', type=int, default=24)
    parser.add_argument('--primes', type=int, nargs='+', default=[2, 7])
    parser.add_argument('--verify', action='store_true', help='verify all companion Lucas/factor certificates')
    args = parser.parse_args()
    if args.verify:
        return verify_factorizations()
    if args.start < 2 or args.start % 2 or args.end < args.start:
        parser.error('start must be even and at least 2, and end must be at least start')
    for e in range(args.start, args.end + 1, 2):
        values = residual_constraints(e, args.primes)
        print(e, reduce(gcd, values), *values, flush=True)


if __name__ == '__main__':
    main()
