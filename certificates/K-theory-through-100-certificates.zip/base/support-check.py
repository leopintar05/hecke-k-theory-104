"""Verify the recorded prime-support identities for the field of discriminant -3.

Quick mode uses only Python's standard library and classical-series.py.
--recompute independently
generates each classical product and the Hecke matrices defining the recorded
G. It also needs the companion files and the python-flint and NumPy packages.
"""
from argparse import ArgumentParser
from fractions import Fraction
from functools import cache
from math import comb,gcd,isqrt,prod
from pathlib import Path
from runpy import run_path
import json


@cache
def character_bernoulli(n):
    # Sum B_n(eta_3)t^n/n! = -t exp(t)/(1 + exp(t) + exp(2t)).
    if n == 0:
        return Fraction(0)
    return (-n-sum(comb(n,j)*(1+2**j)*character_bernoulli(n-j) for j in range(1,n+1)))/3


def strip(n,divisors):
    while (part:=gcd(n,divisors)) > 1:
        n//=part
    return n


def adjoint_at_two(core,e):
    k=e+1
    n=max(0,(k-6)//3+1)
    if n==0:
        return 1
    basis=core["basis"](k,2*n)
    t=core["hecke"](basis,2,k)
    square=[[sum(a*b for a,b in zip(row,col)) for col in zip(*t)] for row in t]
    first=core["det_shift"](square,(2**e-1)**2)
    second=core["det_shift"](square,-(2**e+1)**2)
    return abs(first*second)


def check_rows(table,companions,weights,recompute):
    classical_core=run_path(str(companions/"classical-series.py"))
    classical=classical_core["residual_constraints"]
    if recompute:
        compact=run_path(str(Path(__file__).with_name("batch-compact.py")))["determinants"]
        basis=run_path(str(companions/"compact-series.py"))["basis"]
    material=json.loads(table.read_text())
    assert [row["e"] for row in material]==list(range(2,51,2))
    maximum=1
    for row in material:
        e,n,G=row["e"],row["dimension"],int(row["G"])
        if weights and e not in weights:
            continue
        first,second=[abs((character_bernoulli(m)/m).numerator) for m in (e+1,2*e+1)]
        A=first*second
        # The two Bernoulli sources have disjoint prime support above 43.
        assert strip(gcd(first,second),2*7*13*19*31*37*43)==1
        assert strip(gcd(A,2**(2*e)-1),7*13*19*31*37*43*61*73*97)==1
        assert strip(gcd(second,adjoint_at_two(classical_core,e)),
                     7*13*19*31*37*43*53*61*73*97)==1
        ratio=Fraction(G,first*second**3)
        assert G>0 and A>0
        c2,c7=classical(e,[2,7])
        cc=[]
        for c,pair in zip((c2,c7),row["classical_ratios"]):
            reduced=Fraction(c//strip(c,G),second**2)
            cc.extend(((pair[0],reduced.numerator),(pair[1],reduced.denominator)))
        assert len(row["classical_ratios"])==2
        u_g=list(map(int,row["compact_G"]))
        assert len(u_g)==len(row["compact_ratios"])==2
        for saturated,pair in zip(u_g,row["compact_ratios"]):
            assert saturated>0 and strip(saturated,G)==1
            reduced=Fraction(saturated,first*second)
            cc.extend(((pair[0],reduced.numerator),(pair[1],reduced.denominator)))
        for factors,value in (*cc,(row["G_only"],strip(G,A)),(row["A_only"],strip(A,G)),
                              (row["ratio_num"],ratio.numerator),(row["ratio_den"],ratio.denominator)):
            assert value==prod(q**v for q,v in factors)
            assert len({q for q,v in factors})==len(factors)
            for q,v in factors:
                maximum=max(q,maximum)
                assert 2<=q<=337 and v>0 and all(q%j for j in range(2,isqrt(q)+1))
        if recompute:
            assert len(basis(e-1))==n
            u=compact(companions,e)
            assert gcd(c2*u[2],c7*u[7])==G
            assert u_g==[abs(u[q])//strip(abs(u[q]),G) for q in (2,7)]
        print("verified e, dimension, digits of G",e,n,len(str(G)),flush=True)
    if not weights:
        assert maximum==337
    print("largest discrepancy prime in checked rows",maximum,flush=True)
    assert not weights or set(weights)<={r["e"] for r in material}

if __name__=="__main__":
    here=Path(__file__).resolve().parent
    ap=ArgumentParser(description=__doc__)
    ap.add_argument("--table",type=Path,default=here/"support-witnesses.json")
    ap.add_argument("--companions",type=Path,default=here)
    ap.add_argument("--weights",nargs="+",type=int)
    ap.add_argument("--recompute",action="store_true")
    a=ap.parse_args()
    check_rows(a.table,a.companions,a.weights,a.recompute)
