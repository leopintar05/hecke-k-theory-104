"""Evaluate the rationally descended Schur test at odd coefficient primes.

Compile inert_row.c to a shared library and pass it with --library. The input
and output coordinates of the C routine are ordinary canonical residues.
"""
import argparse
from ctypes import CDLL, POINTER, c_uint64, c_int
from itertools import permutations
from math import gcd
from pathlib import Path
from random import Random
from runpy import run_path
from time import monotonic
from flint import nmod_mat, fmpz, fmpz_mod_mat, fmpz_mod_ctx

def encode_basis(B):
    prefs={(0,0,0):0}
    offsets=[0]
    terms=[]
    for d, kind, a, b in B:
        if kind=='symmetric':
            terms.extend((0,12,a,13,b))
        else:
            repeated=0 if d[0]==d[1] else 1
            for perm in permutations(range(3)):
                if kind=='paired' and perm[repeated]>perm[repeated+1]:
                    continue
                prefix=[0,0,0]
                for j,h in zip(perm,d):
                    prefix[j]=2*h
                key=tuple(prefix)
                pre=prefs.setdefault(key,len(prefs))
                if kind=='ordered':
                    i,j,_=perm
                    terms.extend((pre,6+i,a,6+j,b))
                else:
                    i=perm[2 if d[0]==d[1] else 0]
                    terms.extend((pre,6+i,a,9+i,b))
        offsets.append(len(terms)//5)
    keys=[v for key in prefs for v in key]
    return len(prefs), (c_int*len(keys))(*keys), (c_int*len(offsets))(*offsets), (c_int*len(terms))(*terms)

def run(e,p,seed,companions,library,block=False,unit_only=False,sign=0):
    assert p>7 and gcd(p,42)==1 and sign == -1 and unit_only
    C=CDLL(str(library.resolve()))
    C.evaluate.argtypes=(c_int,c_int,c_int,POINTER(c_int),POINTER(c_int),POINTER(c_int),
                         POINTER(c_uint64),POINTER(c_uint64),c_int,POINTER(c_uint64))
    if hasattr(C,'num_words'):
        limbs=C.num_words()
        R=1<<(64*limbs)
        assert 2*p<R
        mask=(1<<64)-1
        def words(values):
            return (c_uint64*(limbs*len(values)))(*(v>>(64*j)&mask for v in values for j in range(limbs)))
        def encode(values):
            return words([x*R%p for x in values])
        rinv=pow(R,-1,p)
        def decode(values):
            return [sum(values[i+j]<<(64*j) for j in range(limbs))*rinv%p
                    for i in range(0,len(values),limbs)]
        C.initialize.argtypes=(POINTER(c_uint64),POINTER(c_uint64))
        C.initialize(words([p]),encode([1]))
        C.field_product.argtypes=(POINTER(c_uint64),POINTER(c_uint64),POINTER(c_uint64))
        rng=Random(seed)
        samples=[0,1,p-1,p-2,p//2]+[rng.randrange(p) for _ in range(30)]
        for a,b in zip(samples,samples[::-1]):
            out=(c_uint64*limbs)()
            C.field_product(encode([a]),encode([b]),out)
            assert decode(out)==[a*b%p]
    else:
        assert p<2**62
        limbs=1
        def encode(values):return (c_uint64*len(values))(*(v%p for v in values))
        def decode(values):return list(values)
        C.initialize.argtypes=(c_uint64,)
        C.initialize(p)
    generic=run_path(str(companions/'compact-series.py'))
    raw=run_path(str(companions/'compact-minus-seven.py'))
    swap=run_path(str(companions/'inert_schur.py'))['swap_columns']
    B=generic['basis'](e-1,2)
    cols=swap(B)
    n=len(B)
    m=e-1
    sample_size=n
    if sign:
        assert sign in (-1,1) and not block
        selected=[]
        for j,(d,kind,a,b) in enumerate(B):
            dual=tuple(-s for s in reversed(d))
            diagonal=(-1)**a if kind=="ordered" else 1
            if d<dual or (d==dual and diagonal==sign): selected.append(j)
        sample_size=len(selected)
        def project_sign(row):
            return [(row[j]+sign*sum(c*row[h] for h,c in cols[j]))%p for j in selected]
    encoding=encode_basis(B)
    u=(2**(2*e)+2**e+1)%p
    assert gcd(u,p)==1
    matrices=[M for j in (1,2) for M in raw['neighbors']['endpoint_matrices'](j)]
    assert len(matrices)==13
    C1=encode([1])
    weights=encode([u*u%p,*([(-u)%p]*6),*([p-1]*7)])
    if sign:
        mixed=run_path(str(companions/"mixed-paths.py"))["mixed"]
        matrices.extend(mixed(companions))
        weights=encode([2*u*u%p,*([(-2*u)%p]*6),*([p-1]*14)])
    def evaluate(coords, coeffs, count):
        points=encode(coords)
        out=(c_uint64*(2*n*limbs))()
        assert C.evaluate(m,n,*encoding,points,coeffs,count,out)==0
        values=decode(out)
        return values[::2],values[1::2]
    rng=Random(seed)
    evals=[]
    rows=[]
    if block and unit_only:
        raise ValueError("select either direct block or single-determinant mode")
    if unit_only:
        result_matrix=(nmod_mat(sample_size,sample_size,p) if p.bit_length()<=63
                       else fmpz_mod_mat(sample_size,sample_size,fmpz_mod_ctx(p)))
    if block:
        assert p.bit_length()<=63, "the optional direct block uses the word-sized FLINT matrix"
        restricted=nmod_mat(2*n,2*n,p)
    for i in range(sample_size):
        a,b,c,d=(rng.randrange(1000,100000) for _ in range(4))
        x,y=(1,a,b),(-a*c-b*d,c,d)
        coords=[v for t in (*x,*y) for v in (t,0)]
        if not unit_only or i<3:
            ev,imag=evaluate(coords,C1,1)
            assert not any(imag)
            if i<3: assert ev==[z%p for z in generic['values'](B,x,y,2)]
            if not unit_only: evals.append(project_sign(ev) if sign else ev)
        for M in matrices:
            for vec,conjugate in ((x,True),(y,False)):
                for col in M:
                    if conjugate:
                        pair=(sum(t*(a+b) for t,(a,b) in zip(vec,col)),
                              -sum(t*b for t,(a,b) in zip(vec,col)))
                    else:
                        pair=(sum(t*a for t,(a,b) in zip(vec,col)),
                              sum(t*b for t,(a,b) in zip(vec,col)))
                    coords.extend(pair)
        aa,bb=evaluate(coords,weights,1+len(matrices))
        if block:
            for j,(a,b) in enumerate(zip(aa,bb)):
                restricted[i,j]=a
                restricted[i,n+j]=(-2*b)%p
                restricted[n+i,j]=b
                restricted[n+i,n+j]=(a+b)%p
        else:
            if sign:
                row=project_sign([(2*a+b)%p for a,b in zip(aa,bb)])
            else:
                bs=[sum(c*bb[j] for j,c in col) for col in cols]
                row=[(a-b+2*s)%p for a,b,s in zip(aa,bb,bs)]
            if unit_only:
                for j,value in enumerate(row): result_matrix[i,j]=value
            else:
                rows.append(row)
        if (i+1)%100==0:print('rows',i+1,flush=True)
    if unit_only:
        print("checking unit",e,p,sample_size,sign,seed,flush=True)
        inv=result_matrix.inv()
        ctx=fmpz_mod_ctx(p)
        identity=fmpz_mod_mat(sample_size,sample_size,ctx)
        for i in range(sample_size): identity[i,i]=1
        assert result_matrix * inv == identity
        print("verified right inverse for signed numerator: e, modulus, dimension, sign, seed =",e,p,sample_size,sign,seed,flush=True)
        return True
    def det(matrix):
        if p.bit_length()<=63:
            return int(nmod_mat(matrix,p).det())
        return int(fmpz_mod_mat(matrix,fmpz_mod_ctx(p)).det())
    den=det(evals)
    assert gcd(den,p)==1
    if block:
        num=int(restricted.det())
        norm=num*pow(den,-2,p)%p
        print('block: e, p, rank, seed, detEvaluation, detRestriction, norm =',
              e,p,2*n,seed,den,num,norm,flush=True)
        assert norm
        return norm
    num=det(rows)
    schur=num*pow(den,-1,p)%p
    if sign:
        print('signed sum: e, p, rank, sign, seed, detEvaluation, detNumerator, detSchur =',
              e,p,sample_size,sign,seed,den,num,schur,flush=True)
        return schur
    norm=schur*schur%p
    print('e, p, rank, seed, detEvaluation, detNumerator, detSchur, norm =',e,p,n,seed,den,num,schur,norm,flush=True)
    assert norm
    return norm

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--companions',type=Path,required=True)
    parser.add_argument('--library',type=Path,required=True)
    parser.add_argument('--sign',type=int,choices=(-1,0,1),default=0,help='signed T+Tbar Schur test to exclude a non-self-dual pair')
    parser.add_argument('--unit-only',action='store_true',help='certify det(E L) nonzero with one streamed matrix')
    parser.add_argument('--block',action='store_true',help='use direct restriction of scalars at a word-sized prime')
    parser.add_argument('--e',type=int,required=True)
    parser.add_argument('--p',type=int,required=True)
    parser.add_argument('--seed',type=int,default=128711)
    a=parser.parse_args()
    start=monotonic()
    run(a.e,a.p,a.seed,a.companions,a.library,a.block,a.unit_only,a.sign)
    print('seconds =',round(monotonic()-start,2),flush=True)
