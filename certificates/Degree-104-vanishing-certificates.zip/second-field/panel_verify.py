"""Certify a square matrix of packed canonical residues by block elimination.

The upper block rows are normalized to identity pivots. At each step, removing
the previous pivot columns is a determinant-preserving block row operation.
An explicitly verified right inverse certifies each new diagonal block.
The optional wait interval allows simultaneous generation of a matrix on disk.
"""
import argparse
import hashlib
from math import gcd
from pathlib import Path
from time import monotonic, sleep
from flint import fmpz_mod_ctx, fmpz_mod_mat

def identity(n,ctx):
    I=fmpz_mod_mat(n,n,ctx)
    for j in range(n):
        I[j,j]=1
    return I

def verify(source,n,modulus,block=128,wait=False):
    start=monotonic()
    ctx=fmpz_mod_ctx(modulus)
    width=(modulus.bit_length()+7)//8
    digest=hashlib.sha256()
    previous=[]
    cuts=list(range(0,n,block))+[n]
    sizes=[b-a for a,b in zip(cuts,cuts[1:])]
    residue=1
    for i,r in enumerate(sizes):
        need=cuts[i+1]*n*width
        while not source.exists() or source.stat().st_size<need:
            if not wait:
                raise ValueError(f"incomplete packed matrix at block {i}")
            sleep(2)
        with source.open("rb") as f:
            f.seek(cuts[i]*n*width)
            data=f.read(r*n*width)
        assert len(data)==r*n*width
        digest.update(data)
        matrix_rows=[]
        for a in range(r):
            raw=data[a*n*width:(a+1)*n*width]
            vals=[int.from_bytes(raw[k:k+width],"little") for k in range(0,len(raw),width)]
            assert all(x<modulus for x in vals)
            matrix_rows.append(vals)
        panel=[fmpz_mod_mat([v[a:b] for v in matrix_rows],ctx) for a,b in zip(cuts,cuts[1:])]
        del data,matrix_rows
        for k,upper in enumerate(previous):
            left=panel[k]
            for j,U in enumerate(upper,k+1):
                panel[j]=panel[j]-left*U
            panel[k]=None
        P=panel[i]
        Q=P.inv()
        assert P*Q==identity(r,ctx)
        d=int(P.det())
        assert gcd(d,modulus)==1
        residue=residue*d%modulus
        previous.append([Q*Z for Z in panel[i+1:]])
        print("pivot verified",cuts[i+1],"of",n,"block determinant",d,"seconds",round(monotonic()-start,1),flush=True)
    assert source.stat().st_size==n*n*width
    digest_hex=digest.hexdigest()
    print("exact determinant",residue,"gcd",gcd(residue,modulus),"signed rank",n,flush=True)
    print("packed SHA-256",digest_hex,flush=True)
    return residue,digest_hex

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file",type=Path)
    parser.add_argument("n",type=int)
    parser.add_argument("modulus",type=int)
    parser.add_argument("--block",type=int,default=128)
    parser.add_argument("--wait",action="store_true")
    a=parser.parse_args()
    verify(a.file,a.n,a.modulus,a.block,a.wait)
