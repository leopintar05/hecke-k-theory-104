"""Schur complement at the inert coefficient prime 80348736972167.

The input matrices are the six first and seven second neighbors for the split
Hecke prime 2 over Q(sqrt(-7)). The doubled determinant is an F_p norm.
"""
import argparse
from math import gcd, comb
from pathlib import Path
from random import Random
from runpy import run_path
from time import monotonic

from flint import fmpz, fmpz_mod_ctx, fmpz_mod_mat, nmod_mat

companion = Path(__file__).resolve().parent
raw = run_path(str(companion / "compact-minus-seven.py"))
P = 80348736972167


def determinant(matrix, p):
    if p.bit_length() <= 63:
        return int(nmod_mat(matrix,p).det())
    return int(fmpz_mod_mat(matrix,fmpz_mod_ctx(p)).det())


def swap_columns(B):
    # On the incidence variety, exchanging x and y negates the sorted weight d.
    # Re-sort by reversing (i,j,k). With distinct weights this changes
    # z_i^a*z_j^b to (-z_i-z_j)^a*z_j^b.
    by_label={label:i for i,label in enumerate(B)}
    columns=[]
    for d,kind,a,b in B:
        dual=tuple(-t for t in reversed(d))
        if kind=="ordered":
            column=[(by_label[(dual,kind,j,a+b-j)], (-1)**a*comb(a,j)) for j in range(a+1)]
        else:
            column=[(by_label[(dual,kind,a,b)],1)]
        columns.append(column)
    return columns


def swapped_row(values,columns,p):
    return [sum(c*values[i] for i,c in col)%p for col in columns]


def run(e,p,seed,descent=False):
    assert fmpz(p).is_prime() and p>7
    assert pow(-7,(p-1)//2,p) == p-1
    elem = raw['QuadraticResidue']
    elem.__init__.__globals__['p']=p
    assert elem(p)==0 and elem(0,1)*elem(0,1)==elem(-2,1)
    B = raw['basis'](e-1,2)
    rng = Random(seed)
    points = []
    ev = []
    for _ in B:
        a,b,c,d = (rng.randrange(-16,17) for _ in range(4))
        x,y = (1,a,b),(-a*c-b*d,c,d)
        points.append((x,y))
        ev.append([v%p for v in raw['values'](B,x,y,2)])
    den = determinant(ev,p)
    if not den:
        # Widely sampled rational incidence points eliminate frequent orbit repeats.
        rng=Random(seed)
        for i in range(len(B)):
            a,b,c,d=(rng.randrange(100000,1000000) for _ in range(4))
            x,y=(1,a,b),(-a*c-b*d,c,d)
            points[i]=(x,y)
            ev[i]=[v%p for v in raw['values'](B,x,y,2)]
        den=determinant(ev,p)
    assert gcd(den,p)==1
    u=(pow(2,2*e,p)+pow(2,e,p)+1)%p
    assert u !=0
    mats=[(coef,M) for j,coef in ((1,-u),(2,-1))
          for M in raw['neighbors']['endpoint_matrices'](j)]
    assert len(mats)==13
    cols=swap_columns(B) if descent else []
    if descent:
        for x,y in points[:5]:
            row=[v%p for v in raw['values'](B,x,y,2)]
            swapped=[v%p for v in raw['values'](B,y,x,2)]
            assert swapped==swapped_row(row,cols,p)
    real,imag=[],[]
    for i,((x,y),evrow) in enumerate(zip(points,ev),1):
        aa,bb=[u*u*t%p for t in evrow],[0]*len(B)
        for c,M in mats:
            xx,yy = raw['numerator_action'](M,x,y)
            hit = raw['values'](B,xx,yy,2)
            aa=[(a+c*z.a)%p for a,z in zip(aa,hit)]
            bb=[(b+c*z.b)%p for b,z in zip(bb,hit)]
        if descent:
            # For L=A+B*w and w=(1+delta)/2: R-3T+4TS = A-B+2BS.
            bb_s=swapped_row(bb,cols,p)
            aa=[(a-b+2*s)%p for a,b,s in zip(aa,bb,bb_s)]
        real.append(aa)
        imag.append(bb)
        if i%100==0:print('rows',i,flush=True)
    if descent:
        num=determinant(real,p)
        schur=num*pow(den,-1,p)%p
        norm=schur*schur%p
        print('descent: e, p, rank, seed, detEvaluation, detNumerator, detSchur, norm =',
              e,p,len(B),seed,den,num,schur,norm,flush=True)
        assert norm !=0
        return norm
    block=[a+[(-2*b)%p for b in y] for a,y in zip(real,imag)]
    block.extend(y+[(c+d)%p for c,d in zip(a,y)] for a,y in zip(real,imag))
    num = determinant(block,p)
    norm = num*pow(den,-2,p)%p
    print('e, p, dim, seed, evaluation determinant, numerator norm, schur norm =',
          e,p,len(B),seed,den,num,norm,flush=True)
    assert norm !=0
    return norm

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--e',type=int,default=22)
    ap.add_argument('--p',type=int,default=P)
    ap.add_argument('--seed',type=int,default=188634)
    ap.add_argument('--descent',action='store_true')
    args=ap.parse_args()
    start=monotonic()
    run(args.e,args.p,args.seed,args.descent)
    print('seconds =',round(monotonic()-start,2))
