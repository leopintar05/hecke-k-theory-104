"""Fast end-to-end comparison of four rows with direct evaluation and an integer determinant."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
from flint import fmpz_mat
from assemble import assemble
from direct_row import direct_row
from panel_verify import verify

def main():
    if not __debug__:raise ValueError('enable Python assertions')
    h=Path(__file__).resolve().parent; base=h/'base'; e=6; N=1009*10007; n=4; seed=128711
    c={'e':e,'modulus':N,'rank':n,'seed':seed}
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);lib=tmp/'control.so';packed=tmp/'control.bin'
        flags=['-dynamiclib'] if sys.platform=='darwin' else ['-shared','-fPIC']
        subprocess.run([os.environ.get('CC','cc'),'-O3','-std=c99','-DL=1',*flags,str(h/'signed_prefix.c'),'-o',str(lib)],check=True)
        assemble(e,N,seed,base,lib,packed,2,2)
        width=(N.bit_length()+7)//8
        direct=[direct_row(c,i,base) for i in range(n)]
        assert packed.read_bytes()==b''.join(direct)
        A=fmpz_mat([[int.from_bytes(row[k:k+width],'little') for k in range(0,len(row),width)] for row in direct])
        det,digest=verify(packed,n,N,block=2)
        assert int(A.det())%N==det
        print('all four rows agree with forty-path evaluation; integer determinant agrees',flush=True)
if __name__=='__main__':main()
