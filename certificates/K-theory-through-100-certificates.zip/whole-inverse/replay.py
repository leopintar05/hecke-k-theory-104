"""Repeat the original full right-inverse check for degree 76, 80, or 84."""
import argparse,json,os,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('degree',type=int,choices=(76,80,84))
p.add_argument('--work',type=Path,default=Path('replay-work'))
a=p.parse_args()
if not __debug__:p.error('run with assertions enabled')
h=Path(__file__).resolve().parent; e=a.degree//2
c=json.loads((h.parent/'weights.json').read_text())[str(e)]
limbs=(c['bits']+64)//64
a.work.mkdir(exist_ok=True,parents=True)
lib=a.work.resolve()/f'whole-{limbs}.so'
flags=['-dynamiclib'] if sys.platform=='darwin' else ['-shared','-fPIC']
subprocess.run([os.environ.get('CC','cc'),'-O3','-std=c99',f'-DL={limbs}',*flags,str(h/'signed_trace.c'),'-o',str(lib)],check=True)
subprocess.run([sys.executable,'-u',str(h/'signed_composite.py'),'--e',str(e),'--p',str(c['modulus']),'--seed',str(c['seed']),'--library',str(lib),'--companions',str(h.parent/'base'),'--sign','-1','--unit-only'],check=True)
