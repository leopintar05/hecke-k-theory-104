# The dimension of the negative space in every even exponent

Write e=2k and m=2k−1. On the standard lattice over Q(√−7) the automorphism group is the signed permutation group in three dimensions. Its central inversion acts trivially in bidegree (m,m), so average over the 24 orientation-preserving signed permutations, the rotation group of the cube. Write U_j=Sym^j(Q³). Before imposing the incidence relation x·y=0, swapping x and y has negative space ∧²U_j in bidegree (j,j). Multiplication by the invariant, swap-symmetric polynomial x·y embeds the preceding bidegree. Taking invariants and the negative eigenspace is exact in characteristic zero. Thus the negative rank equals dim(∧²U_m)^H−dim(∧²U_{m−1})^H.

For a cube rotation g, write h_j(g) for the trace on U_j. A rotation through θ has generating function 1/((1−t)(1−2t cosθ+t²)), and the trace on ∧²U_j is (h_j(g)²−h_j(g²))/2. The cube rotation angles and counts are 0 (one), π (nine), ±π/2 (six), and ±2π/3 (eight). Let Δ denote the difference from j=2k−2 to j=2k−1.

| Angle | Δ(h_j(g)²−h_j(g²)) |
|---|---:|
| 0 | 2k(4k²−1) |
| π | −2k |
| ±π/2 | 2k |
| ±2π/3 | 0 |

Indeed, the identity traces at the two degrees are k(2k−1), k(2k+1). At π they are k and −k. At a quarter turn the coefficients of (1+t)/(1−t⁴) are equal in each pair of consecutive even and odd degrees, and the square is a half turn. At a third turn the coefficients of 1/(1−t³) belong to {0,1} and g² has the same traces. Averaging gives

    [2k(4k²−1)−18k+12k]/48 = k(k²−1)/6 = binom(k+1,3).

This gives independently the signed ranks 1140, 1330, 1540, 1771, 2024, 2300 and 2600 in degrees 76 through 100.

The same computation gives the positive rank without another orbit count. The trace of the swap on (U_j⊗U_j)^H is the average of h_j(g²). Subtracting the preceding bidegree gives (8k+8δ)/24, where δ=[3 divides 2k−1]−[3 divides 2k−2]. This equals floor((k+1)/3). Thus the positive rank exceeds the negative rank by floor((k+1)/3), and the full standard-class rank is 2 binom(k+1,3)+floor((k+1)/3).
