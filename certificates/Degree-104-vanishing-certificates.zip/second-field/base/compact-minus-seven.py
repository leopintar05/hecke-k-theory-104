"""Modular Schur-complement test at the split prime 2 over Q(sqrt(-7)).

Run from any directory with Python 3; keep compact-series.py and
minus-seven-neighbors.py beside this file. No external package is needed.
"""
from argparse import ArgumentParser
from math import gcd, isqrt, prod
from pathlib import Path
from runpy import run_path
from time import monotonic

root = Path(__file__).parent
generic = run_path(str(root/"compact-series.py"))
neighbors = run_path(str(root/"minus-seven-neighbors.py"))
basis, values, sample_points = (generic[k] for k in ("basis","values","sample_points"))
PRIME16 = 25078104767246023
REMAINDER20 = 8668939497138560640847591531306324081663534478090773005701622260923927722505598427880702021168256675999139133542083
BASES20 = (9496386083,175427911,552972895573825165951583191)
p = PRIME16


def prime_certificate():
    assert p == PRIME16
    divisors = {2: 1, 3: 3, 10487: 1, 44284289839: 1}
    assert prod(q**v for q,v in divisors.items()) == p-1
    assert all(all(q % i for i in range(2, isqrt(q)+1)) for q in divisors)
    assert pow(3,p-1,p) == 1
    assert all(gcd(pow(3,(p-1)//q,p)-1,p)==1 for q in divisors)
    assert pow(-7,(p-1)//2,p) == p-1


class QuadraticResidue:
    """a+b*w modulo the current odd modulus, w²=w−2. The ring may split."""
    __slots__ = ("a","b")

    def __init__(self, a, b=0):
        self.a, self.b = a % p, b % p

    def bar(self):
        return QuadraticResidue(self.a+self.b,-self.b)

    def __add__(self, other):
        if isinstance(other,int):
            return QuadraticResidue(self.a+other,self.b)
        return QuadraticResidue(self.a+other.a,self.b+other.b)

    __radd__ = __add__

    def __neg__(self):
        return QuadraticResidue(-self.a,-self.b)

    def __sub__(self, other):
        return self + (-other)

    def __rsub__(self, other):
        return -self + other

    def __mul__(self, other):
        if isinstance(other,int):
            return QuadraticResidue(self.a*other,self.b*other)
        a,b,c,d = self.a,self.b,other.a,other.b
        return QuadraticResidue(a*c-2*b*d, a*d+b*c+b*d)

    __rmul__ = __mul__

    def __pow__(self,n):
        assert n >= 0
        if n == 0:
            return QuadraticResidue(1)
        if n == 1:
            return self
        v = self**(n//2)
        square = v*v
        return square*self if n%2 else square

    def __eq__(self,other):
        if isinstance(other,int):
            return self.b == 0 and self.a == other%p
        if isinstance(other,QuadraticResidue):
            return self.a == other.a and self.b == other.b
        return NotImplemented


def det_mod(rows):
    a = [[x%p for x in row] for row in rows]
    n = len(a)
    res = 1
    for k in range(n):
        if k == n-1:
            return res*a[k][k]%p
        pivot_at = next((i for i in range(k,n) if gcd(a[i][k],p)==1),None)
        if pivot_at is None:
            if all(a[i][k]==0 for i in range(k,n)):
                return 0
            raise ArithmeticError("No invertible pivot over the composite modulus")
        if pivot_at != k:
            a[pivot_at], a[k] = a[k], a[pivot_at]
            res = -res
        pivot = a[k][k]
        res = res*pivot%p
        inv = pow(pivot,-1,p)
        for i in range(k+1,n):
            factor = a[i][k]*inv%p
            if factor:
                a[i][k:] = [(x-factor*y)%p for x,y in zip(a[i][k:],a[k][k:])]
    return res


def numerator_action(columns, x, y):
    # The input is a right coset representative M/bar(w)^j.  Evaluating a
    # polynomial on (g^-1 x, g^t y) uses adjoint(M) and transpose(M).
    xv = [sum(QuadraticResidue(*entry).bar()*t for entry,t in zip(column,x)) for column in columns]
    yv = [sum(QuadraticResidue(*entry)*t for entry,t in zip(column,y)) for column in columns]
    return xv,yv


def calculate(e, modulus, verbose=False, seed=78001):
    global p
    p = modulus
    assert p > 1 and p % 2
    if p == PRIME16:
        prime_certificate()
    B = basis(e-1,unit_order=2)
    pts, ev = sample_points(B,unit_order=2,seed=seed)
    d = det_mod(ev)
    assert gcd(d,p) == 1
    u = (2**(2*e)+2**e+1) % p
    assert gcd(u,p) == 1
    singles = neighbors["endpoint_matrices"](1)
    doubles = neighbors["endpoint_matrices"](2)
    rows = []
    for (x,y),ev_row in zip(pts,ev):
        r = [QuadraticResidue(u*u*v) for v in ev_row]
        for coeff, matrices in ((-u,singles),(-1,doubles)):
            for columns in matrices:
                xv,yv = numerator_action(columns,x,y)
                acts = values(B,xv,yv,unit_order=2)
                r = [s+coeff*t for s,t in zip(r,acts)]
        rows.append(r)
    # Restriction of scalars: multiplication by a+b*w has matrix
    # [[a,-2b],[b,a+b]].  The determinant is the field norm.
    real = [[z.a for z in r] for r in rows]
    imag = [[z.b for z in r] for r in rows]
    block = [a + [-2*v for v in b] for a,b in zip(real,imag)]
    block += [b + [c+d for c,d in zip(a,b)] for a,b in zip(real,imag)]
    numerator_norm = det_mod(block)
    schur_norm = numerator_norm*pow(d,-2,p)%p
    if verbose:
        print(f"p={p} e={e} m={e-1} dimension={len(B)}")
        print(f"evaluation determinant = {d}")
        print(f"norm of evaluation times Schur determinant = {numerator_norm}")
        print(f"norm of Schur determinant modulo p = {schur_norm}")
    return schur_norm


if __name__ == "__main__":
    start=monotonic()
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--e",type=int,default=16)
    parser.add_argument("--modulus",type=int)
    parser.add_argument("--seed",type=int,default=78001)
    parser.add_argument("--repeat",action="store_true")
    args=parser.parse_args()
    if args.modulus is not None:
        mod=args.modulus
    elif args.e == 16:
        mod=PRIME16
    elif args.e == 20:
        f,g,h=BASES20
        assert REMAINDER20 == f*(g*h)**3
        mod=f*g*h
    else:
        parser.error("give --modulus explicitly for this degree")
    result=calculate(args.e,mod,verbose=True,seed=args.seed)
    if args.e == 16 and mod == PRIME16:
        assert result == 2878404798502841
    if args.e == 20 and mod == prod(BASES20):
        assert result == 579595526356272233641338277062997366134033614
        assert gcd(result,mod) == 1
    print("gcd of norm and modulus =", gcd(result,mod), flush=True)
    if args.repeat:
        assert calculate(args.e,mod,seed=args.seed+15071) == result
    print(f"elapsed = {monotonic()-start:.2f}s")
