"""Returning split-at-2 Hecke paths for the two-class unitary genus over Q(sqrt(-7)).

A column entry (a,b) represents a+b*w, w=(1+sqrt(-7))/2, w^2=w-2.
For a length-j path, the rational matrix of the endpoint is M/bar(w)^j.
"""
from itertools import product, combinations
from math import isqrt


def mul(x,y):
    a,b=x
    c,d=y
    return a*c-2*b*d, a*d+b*c+b*d


def bar(x):
    a,b=x
    return a+b,-b


def dot(x,y):
    terms=[mul(bar(a),b) for a,b in zip(x,y)]
    return tuple(map(sum,zip(*terms)))


def norm(x):
    a,b=x
    return a*a+a*b+2*b*b


def norm_lines(n):
    # Norm(a+b*w) = (a+b/2)^2+7b^2/4 >= (a^2+b^2)/2.
    radius=isqrt(2*n)+1
    by_norm={}
    for x in product(range(-radius,radius+1),repeat=2):
        if norm(x)<=n: by_norm.setdefault(norm(x),[]).append(x)
    vecs=set()
    for r in by_norm:
        for s in by_norm:
            for v in product(by_norm[r],by_norm[s],by_norm.get(n-r-s,[])):
                neg=tuple((-a,-b) for a,b in v)
                vecs.add(min(v,neg))
    return sorted(vecs)


def span(cols, modulus):
    # The even root of w^2-w+2 is 0 mod 2 and 2 mod 4.
    w=0 if modulus==2 else 2
    red=[[a+w*b for a,b in v] for v in cols]
    return frozenset(tuple(sum(c*red[j][i] for j,c in enumerate(cs)) % modulus
                           for i in range(3))
                     for cs in product(range(modulus),repeat=3))


def endpoint_matrices(j):
    n=2**j
    vecs=norm_lines(n)
    if j==2: # all endpoints must lie in the unique missing first hyperplane at w
        vecs=[v for v in vecs if sum(a for a,b in v)%2==0]
    perpendicular={i:{k for k in range(i+1,len(vecs)) if dot(vecs[i],vecs[k])==(0,0)}
                   for i in range(len(vecs))}
    out={}
    for i in perpendicular:
        for k in sorted(perpendicular[i]):
            for h in sorted(perpendicular[i]&perpendicular[k]):
                M=(vecs[i],vecs[k],vecs[h])
                # Exact determinant valuations follow from index modulo n
                # and the certified determinant norm. Test modulo 8 too.
                a,b=determinant(M)
                w8=6
                if (a+w8*b)%8 not in ({2,6} if j==1 else {4}): continue
                assert norm((a,b))==n**3
                H=span(M,n)
                assert len(H)==n**2 and H not in out
                out[H]=M
    assert len(out)==(6 if j==1 else 7)
    if j==1:
        missing=frozenset(x for x in product(range(2), repeat=3) if sum(x)%2==0)
        assert missing not in out
    return list(out.values())


def determinant(M):
    from itertools import permutations
    a=b=0
    for perm in permutations(range(3)):
        v=(1,0)
        for j,i in enumerate(perm): v=mul(v,M[j][i])
        sign=(-1)**sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
        a+=sign*v[0]; b+=sign*v[1]
    return a,b


if __name__=='__main__':
    print("returning right cosets from one step and via the other class:",
          [len(endpoint_matrices(j)) for j in (1,2)])
